Nombre: Cristobal Andrés Pino Poblete
Rol: 202104597-k

Las funciones encode, decode (ambas recursiones) y integrar de recursión simple funcionan sin problemas. Integrar de recursión de cola funciona pero hay errores en los resultados. No pude lograr cambiar los valores de los nodos en map_arbol de manera que coincidieran con los resultados del pdf, asi que deje lo que pude desarrollar.