% Declaración de predicados para armar el grafo,
% de manera dirigda.
vecino(a,b).
vecino(a,c).
vecino(a,e).
vecino(b,c).
vecino(c,d).
vecino(c,e).
vecino(e,b).
vecino(f,b).
vecino(f,e).
vecino(f,g).
vecino(g,e).
vecino(h,g).
vecino(h,j).
vecino(h,i).
vecino(i,g).
vecino(j,g).
vecino(j,i).

% Consulta 1: Puede llegar?

% Función auxiliar "destino" caso 1, donde se revisa
% si son vecinos directos.
destino(X, Y, _) :-
    vecino(X, Y).

% Función auxiliar "destino" caso 2, donde se revisan los
% vecinos indirectos del nodo. Primero se revisa con
% una consulta del predicado y se chequea si el nodo
% indirecto no ha sido visitado todavia. Por lo que
% es agregado a una lista donde se guardan todos los
% nodos ya visitados.
destino(X, Y, Visited) :-
    vecino(X, Z),
    \+ member(Z, Visited),
    destino(Z, Y, [Z|Visited]).

% Función "puedellegar" caso 1: se llama a la función
% auxiliar y se encuentran todos los casos posibles
% que coincidan como vecinos directos. Luego de esto, 
% se hace uso de las funciones 'sort' y 'member' para 
% ordenar la lista de nodos unicos y eliminar 
% los duplicados.
puedellegar(X, Y) :-
    findall(X, destino(X, Y, []), Nodos),
    sort(Nodos, NodosNoRepetidos),
    member(X, NodosNoRepetidos).

% Función "puedellegar" caso 2: mismas ideas que 
% arriba, pero en este caso se encuentran los casos
% que coincidan como vecinos indirectos.
puedellegar(X, Y) :-
    findall(Z, destino(X, Z, []), Paths),
    sort(Paths, UniquePaths),
    member(Y, UniquePaths).

% Consulta 2: Vecinos.

% Funcion "vecinos": con el uso del predicado
% 'findall' se pueden buscar todos los vecinos de 
% un nodo X y estos se guardan en una lista L de
% manera sencilla.
vecinos(X,L):-
    findall(Z,vecino(X,Z),L).

% Consulta 2: camino válido.

% Función "caminovalido": revisa 3 instancias.
% La primera se encarga de ver si se entrega
% una lista vacía. La segunda revisa si solo
% se entrega un nodo en la lista. Y el último
% caso recibe una lista con al menos
% 2 nodos, donde revisa con un predicado si
% estos nodos son vecinos. Si es correcto,
% se llamará a la función de nuevo para continuar
% con el resto de la lista.
caminovalido([]).
caminovalido([_]).
caminovalido([X,Y|L2]):-
    vecino(X,Y),
    caminovalido([Y|L2]).

% Consulta 4: camino más corto.

% Funcion "caminomascorto" y "caminomascorto2":
% las 2 funciones van de la mano. La mayoría del
% trabajo recae en la funcion auxiliar, que tiene
% como parametros los nodos de inicio y fin, una 
% lista de nodos ya visitados y una lista de la ruta. 
% En primera instancia revisa si la lista de ruta es
% vacia y si los nodos de inicio y fin son iguales.
% En caso contrario, se consulta si el nodo X de inicio
% es vecino con la cabeza de la lista de ruta, mientras
% que se revisa a la vez si el nodo no ha sido visitado.
% Si es asi, entonces se llama de nuevo a la función
% auxiliar para continuar con el resto de la lista y que
% ésta pueda concluir cuando se alcance el final.
caminomascorto(X, Y, L):-
    caminomascorto2(X, Y, [X], L).
caminomascorto2(X, X, _, [X]).
caminomascorto2(X, Y, Mem, [X|Ruta]):-
    vecino(X,Z),
    \+ member(Z, Mem),
    caminomascorto2(Z, Y, [Z|Mem], Ruta), !.