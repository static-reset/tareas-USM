Nombre: Cristobal Andrés Pino Poblete
Rol: 202104597-k

Instrucciones: usar el sitio web SWISH de SWI Prolog para probar cualquiera de las consultas, se deben incluir los predicados
de todos los vecinos. Simplemente seguir las instrucciones de cada función y los parametros que reciben. Todos los casos de
prueba fueron revisados y ejecutados con éxito, junto con otros que no estaban en el PDF de la tarea.