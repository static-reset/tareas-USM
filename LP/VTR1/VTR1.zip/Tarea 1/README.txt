Nombre = Cristobal Andrés Pino Poblete
Rol = 202104597-k

Instrucciones: solo funciona con int main, lineas simples como declaraciones/operadores unarios y binarios/condiciones/igual/etc. Lo ideal es tener un espacio entre texto y un ;.
Estan escritos los regex de todos los EBNF que mencionaron en el PDF, pero por temas de tiempo y complejidad no pude probarlos en el programa para su formateo.
Si no existe un match con el regex de main en general, el programa le informara al usuario con un mensaje en la consola. No se haran cambios al texto al formatearlo si no hace match.
