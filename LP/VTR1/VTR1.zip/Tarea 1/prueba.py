import re

digito = r"[1-9]" #Listo
digito_o_zero = r''+ digito +r'|[0-9]*' #Listo
variable = r'([A-Z]|[a-z]|'+ digito_o_zero+r')+' #Listo
entero = r''+ digito +r'('+ digito_o_zero +r')*' #Listo
booleano = r'True|False' #Listo
string = r'#([A-Z]|[a-z]|'+ digito_o_zero +r')+#' #Listo
espacio = r'( |\t|\n)*' #Listo
oper_bin = r'('+ entero +r'|'+ booleano +r'|'+ string +r'|'+ variable +r')'+ espacio +r'(\+|-|/|\*|<|=)'+ espacio +r'('+ entero +r'|'+ booleano +r'|'+ string +r'|'+ variable +r')' #Listo
oper_bin_ani = r'('+ entero +r'|'+ booleano +r'|'+ string +r'|'+ variable +r')'+ espacio +r'(\+|-|/|\*|<|=)'+ espacio +r''+ oper_bin +r'' #Listo
condicion = r'('+ entero +r'|'+ booleano +r'|'+ string +r'|'+ variable +r')'+ espacio +r'(<|==)'+ espacio +r'('+ entero +r'|'+ booleano +r'|'+ string +r'|'+ variable +r')' #Listo
condicion_ani = r'('+ entero +r'|'+ booleano +r'|'+ string +r'|'+ variable +r')'+ espacio +r'(<|==)'+ espacio +r''+ condicion +r'' #Listo
tipo = r'(int|bool|str)' #Listo
declaracion = r''+ tipo +r''+ espacio +r'(\*)*'+ variable +r' ;' #Listo
igual = r''+ variable +r' = '+ oper_bin +r';' #Listo
bloque = r'{'+ espacio +r'('+ espacio +r'('+ declaracion +r'|'+ igual +r'))'+ espacio +r'}' #Falta arreglar linea y probar. Arreglaria el resto.
condicional = r'if'+ espacio +r'\('+ espacio +r''+ condicion +r''+ espacio +r'\)'+ espacio +r'else' #Funciona hasta el else. Hay que ver el bloque. ##'+ espacio +r''+ bloque +r'
ciclo = r'while'+ espacio +r'\('+ espacio +r''+ condicion +r''+ espacio +r'\)' #Funciona bien en la declaracion. Hay que ver el bloque. #'+ espacio +r''+ bloque +r'
linea_ani = r'(?:'+ declaracion +r'|'+ igual +r'|'+ condicional +r'|'+ ciclo +r')' #Todas las Regex funcionan aqui.
main = r'^int'+ espacio +r'main\(\)'+ espacio +r'{'+ espacio +r'return'+ espacio +r'0'+ espacio +r';'+ espacio +r'}$' #Funciona sin considerar lineas entre corchetes.

#config = open('config.txt')
#cantidad_valores = []
#for linea in config:
#    for caracter in linea:
#        if caracter != " ":
#            caracter = int(caracter)
#            cantidad_valores.append(caracter)
#config.close

def configuracion():
    cantidad_valores = []
    with open('config.txt') as config:
        for linea in config:
            for caracter in linea:
                if caracter != " ":
                    caracter = int(caracter)
                    cantidad_valores.append(caracter)
    return cantidad_valores
print(configuracion())

match = re.match(main,"bool KDSHFV3 ;")
print(match)