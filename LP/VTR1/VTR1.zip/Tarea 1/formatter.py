import re;

#EXPRESIONES REGULARES basadas en el EBNF.

#Expresiones y operaciones basicas.
digito = r"[1-9]"
digito_o_zero = r''+ digito +r'|[0-9]*'
variable = r'([A-Z]|[a-z]|'+ digito_o_zero+r')+'
entero = r''+ digito +r'('+ digito_o_zero +r')*'
booleano = r'True|False'
string = r'#([A-Z]|[a-z]|'+ digito_o_zero +r')+#'
espacio = r'[\s*|\t*|\n*]'
valor = r'(?:'+ entero +r'|'+ booleano +r'|'+ string +r'|'+ variable +r')'

#Expresiones operatorias unarias y binarias.
oper_bin = r''+ valor +r''+ espacio +r'(\+|-|/|\*|<|=)'+ espacio +r''+ valor +r''
oper_bin_ani = r''+ valor +r''+ espacio +r'(\+|-|/|\*|<|=)'+ espacio +r''+ oper_bin +r''
condicion = r''+ valor +r''+ espacio +r'(<|==)'+ espacio +r''+ valor +r''
condicion_ani = r''+ valor +r''+ espacio +r'(<|==)'+ espacio +r''+ condicion +r''
tipo = r'(int|bool|str)'
declaracion = r''+ tipo +r''+ espacio +r'(\*)*'+ variable +r' ;' #Considera si se declara un puntero en la linea.
igual = r''+ variable +r''+ espacio +r'='+ espacio +r'('+ valor +r'|'+ oper_bin +r')'+ espacio +r';'

#Expresiones generales y anidadas.
bloque = r'{'+ espacio +r'('+ espacio +r'('+ declaracion +r'|'+ igual +r'))'+ espacio +r'}'
condicional = r'if'+ espacio +r'\('+ espacio +r''+ condicion +r''+ espacio +r'\)'+ espacio +r''+ bloque +r''+ espacio +r'else'+ espacio +r''+ bloque +r''
ciclo = r'while'+ espacio +r'\('+ espacio +r''+ condicion +r''+ espacio +r'\)'+ espacio +r''+ bloque +r''
linea_ani = r''+ declaracion +r'|'+ igual +r'|'+ condicional +r'|'+ ciclo +r''
main = r'^int'+ espacio +r'main\(\)'+ espacio +r'{('+ espacio +r''+ linea_ani +r')+'+ espacio +r'return'+ espacio +r'0'+ espacio +r';'+ espacio +r'}$'
#Todas las expresiones fueron probadas y verificadas con texto simple. No se probaron las expresiones anidadas o mas complejos.

#Lectura de configuración.
def configuracion():
    cantidad_valores = []
    with open('config.txt') as config:
        for linea in config:
            for caracter in linea:
                if caracter != " ":
                    caracter = int(caracter)
                    cantidad_valores.append(caracter)
    return cantidad_valores
#Funcion que crea una lista, lee el archivo de texto de configuracion, recorre la linea (transformando los caracteres que no son espacios en enteros) y guarda los valores en la lista. Si se desea se pueden guardar los valores en variables separadas.

#Con el uso de "with _ as _" podemos usar las funciones de lectura/escritura de archivos sin preocuparse de cerrar el archivo con una declaracion.
with open('codigo.txt', 'r') as codigo, open('formateado.txt', 'w') as formateado:
    configuracion()
    cantEspacio = " "*configuracion()[0]
    cantSaltosLinea = "\n"*configuracion()[1]
    cantTab = "\t"*configuracion()[2]
    #Lo primero que se hace es tener la configuración de espacios/saltos de linea/tabulado listos como variables para usarlos después.
    linea_codigo = ""
    for linea in codigo:
        linea_codigo += linea.strip()
    #Se lee el archivo de codigo por linea y se transforma en un string de una linea.
    if re.match(main, linea_codigo) == None:
        print("El codigo no esta correcto.")
    else:
        for caracter in linea_codigo:
        #Se recorre la linea por caracter, escribiendo cada uno y con condiciones para los caracter especiales abajo.
            if caracter != "{" and caracter != "}" and caracter != ";":
                formateado.write(caracter)
            #Si no coincide con ninguno de esos caracteres especiales, se escribe el caracter tal cual.
            if caracter == "{":
                formateado.write(caracter+cantSaltosLinea+cantTab)
                #Si se encuentra una apertura de corchete, se tabula para poder hacer claro que las lineas que siguen estan dentro del conjunto.
                #En caso de haber ocupado ciclos, condicionales o bloques teniamos un contador disponible y aqui aumentabamos en 1 el contador.
            elif caracter == ";":
                formateado.write(caracter+cantSaltosLinea+cantTab)
                #Para mantener el formateo si esta dentro de un bloque, se escribe un \t para que siga en la misma linea.
            elif caracter == " ":
                formateado.write(cantEspacio)
            #Simplemente se reemplaza el unico espacio por la cantidad de espacios que indica la configuracion.
            elif caracter == "}":
                pass
            #Este ultimo if es importante, ya que para evitar exceso de cierre de corchetes saltamos escribirlo para poder arreglarlo manualmente.

with open('formateado.txt', 'r') as for_read:
    for_leer = for_read.readlines()
    #Se guardan todas las lineas de lo que ya fue formateado.
with open('formateado.txt', 'w') as format_nuevo:
    format_nuevo.writelines(for_leer[:-1])
    format_nuevo.write("}")
    #Se escribe de nuevo todas las lineas formateadas, pero se elimina la ultima (que era compuesta de \t*cantTab). Luego se escribe el cierre de corchete } para poder cerrar de manera correcta el if.