#include <stdio.h>
#include "arbol.h"
#include <stdlib.h>

int main(){
    
    Nodo* main_padre = (Nodo*) malloc(sizeof(Nodo));
    main_padre->padre = NULL;
    strcpy(main_padre->tipo, "Directorio");
    Directorio* dir_padre = (Directorio*) (main_padre->contenido);
    crear_nodo(main_padre, "Archivo", "prueba");
    Lista* lista = (Lista*) crear_lista(2);
    insertar_lista(lista, main_padre);

    while(1){
        char comando[64], nombre_archivo[128], contenido[1000];
        scanf("%s %s %s",comando, nombre_archivo, contenido);
        if(strcmp(comando, "touch") == 0){
            touch(main_padre, nombre_archivo);
            printf("Comando: %s\n", comando);
            printf("Nombre archivo: %s\n", nombre_archivo);
        } else if (strcmp(comando, "ls") == 0){
            ls(main_padre);
        } else if(strcmp(comando, "write") == 0){
            write(main_padre, nombre_archivo, contenido);
            printf("Comando: %s\n", comando);
            printf("Nombre archivo: %s\n", nombre_archivo);
            printf("Contenido: %s\n", contenido);
        }
    }

    free(main_padre->contenido);
    free(main_padre);

    return 0;
}