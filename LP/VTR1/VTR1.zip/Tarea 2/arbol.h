#include <stdio.h>
#include <string.h>
#include <stdlib.h>


//Definición de los structs a usar.
typedef struct Nodo{
    struct Nodo* padre;
    char tipo[64]; //Sirve para castear al ingresar contenido.
    void* contenido;
} Nodo;

//Tipo == "numero", contenido -> int
//Tipo == "caracter", contenido -> char

typedef struct Lista{
    int largo_actual;
    int largo_maximo;
    Nodo* arreglo;
} Lista;

typedef struct Directorio{
    char nombre[128];
    Lista* hijos;
} Directorio;

typedef struct Archivo{
    char nombre[128];
    char contenido[256];
} Archivo;

//Funciones de las estructuras de datos. Las definí a todas por si llegaba a hacer alguna más aparte de la entrega mínima.

Lista* crear_lista(int largo_maximo_inicial);

void insertar_lista(Lista* lista, Nodo* nodo);

Nodo* crear_nodo(Nodo* padre, char* tipo_, char* nombre);

void touch(Nodo* actual, char* nombre_archivo);

void ls(Nodo* actual);

void mkdir(Nodo* actual, char* nombre_directorio);

void write(Nodo* actual, char* nombre_archivo, char* contenido);

Nodo* buscar_directorio(Directorio* actual, char* nombre);

Nodo* buscar_archivo(Directorio* actual, char* nombre);

void limpiar_memoria(Nodo* nodo);