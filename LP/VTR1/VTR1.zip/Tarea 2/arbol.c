#include <stdio.h>
#include "arbol.h"
#include <stdlib.h>

/*void limpiar_memoria(Nodo* nodo){
    free(nodo->contenido);
    free(nodo);
    nodo = NULL;
}*/
/*Recibe un entero que funciona como el largo inicial para la lista, la cual se crea pidiendo memoria para la lista y el nodo.*/
Lista* crear_lista(int largo_maximo_inicial){
    Lista *nueva_lista = (Lista*) malloc(sizeof(Lista)); /*Se pide la memoria para la lista.*/
    nueva_lista->largo_maximo = largo_maximo_inicial; /*La variable que recibe la funcion es asignada para darle el largo maximo a la lista en su primer uso.*/
    nueva_lista->largo_actual = 0; /*El largo actual estará vacío ya que se recién se creo la lista.*/
    Nodo *arreglo_ = (Nodo*) malloc(sizeof(Nodo)); /*Solo por si acaso se pide memoria para el nodo de arreglo de la lista enlazada.*/
    nueva_lista->arreglo = arreglo_; /*Se asigna el nodo de arreglo recién creado a la lista*/
    printf("Se creó la lista.\n");
    return nueva_lista; /*Retorna la lista creada, la cual se puede guardar en otra variable.*/
}

/*Se inserta una lista existense al unirla al directorio actual*/
void insertar_lista(Lista* lista, Nodo* nodo){
    if(lista->largo_actual >= lista->largo_maximo){ /*Condicional que chequea si el largo actual ya alcanzó el largo máximo, para pedir mas memoria.*/
        printf("Entré 1.\n");
        lista->arreglo = (Nodo*) realloc(lista->arreglo, 2*lista->largo_maximo*sizeof(Nodo)); /*Se pide el doble de memoria de antes, se copia y pega lo que ya existia y se libera la memoria anterior.*/
        lista->largo_maximo = 2*(lista->largo_maximo); /*Se multiplica el largo máximo de la lista.*/
        lista->arreglo[lista->largo_actual] = *nodo; /*Se inserta el nodo en la posición actual del arreglo de lista enlazada.*/
        lista->largo_actual++; /*Se aumenta la variable de largo actual, para que se continue en la siguiente posición en caso de insertar más listas.*/
    } else{ /*En caso de que el largo máximo no haya sido superado, solamente se inserta el nodo en la posición actual y se aumenta el contador de posición de largo actual.*/
        printf("Entré 2.\n");
        lista->arreglo[lista->largo_actual] = *nodo; /*Se inserta el nodo en la posición actual del arreglo de lista enlazada.*/
        lista->largo_actual++; /*Se aumenta la variable de largo actual, para que se continue en la siguiente posición en caso de insertar más listas.*/
    }
}

Nodo* crear_nodo(Nodo* padre_, char* tipo_, char* nombre){ /*Función que crea un nodo, considerando los 2 tipos de contenidos que puede tener este nodo para el casteo.*/
    Nodo *nuevo_nodo = (Nodo*) malloc(sizeof(Nodo)); /*Se pide la memoria para el nuevo nodo.*/
    nuevo_nodo->padre = (Nodo*) padre_; /*Inmediatamente se apunta al nodo padre que se recibe como parametro, se puede de todos modos especificar si no se quiere apuntar a un nodo padre.*/
    strcpy(nuevo_nodo->tipo, tipo_); /*Se copia el char* que se recibe para reconocer el tipo de archivo que será guardado en el puntero.*/
    printf("Nodo parte 1 listo.\n");
    /*En esta parte de la funcion se cumple la misma función, solo se diferencia por el tipo de casting que se va a usar dependiendo del tipo de contenido que se va a guardar.*/
    if(strcmp(nuevo_nodo->tipo, "Directorio") == 0){ /*Si es de tipo directorio el char* que se recibe, se entra aquí.*/
        printf("Nodo parte 2 listo.\n");
        Directorio* nuevo_directorio = (Directorio*) malloc(sizeof(Directorio)); /*Se pide la memoria de tipo directorio.*/
        Lista* lista_hijos = (Lista*) crear_lista(10);
        nuevo_directorio->hijos = lista_hijos;
        strcpy(nuevo_directorio->nombre, nombre); /*Se copia al directorio el char* del nombre al que se quiere usar para referirse.*/
        nuevo_nodo->contenido = nuevo_directorio; /*El contenido del nodo apuntará al directorio creado.*/
        nuevo_directorio = (Directorio*) (nuevo_nodo->contenido); /*Para asegurar que no queden errores de segmentación, se hace un casteo adicional al contenido para que sea de tipo directorio.*/
    } else if(strcmp(nuevo_nodo->tipo, "Archivo") == 0){
        printf("Nodo parte 2 listo.\n");
        Archivo* nuevo_archivo = (Archivo*) malloc(sizeof(Archivo)); /*Se pide la memoria de tipo archivo.*/
        strcpy(nuevo_archivo->nombre, nombre); /*Se copia al directorio el char* del nombre al que se quiere usar para referirse.*/
        nuevo_nodo->contenido = nuevo_archivo; /*El contenido del nodo apuntará al archivo creado.*/
        nuevo_archivo = (Archivo*) (nuevo_nodo->contenido); /*Para asegurar que no queden errores de segmentación, se hace un casteo adicional al contenido para que sea de tipo archivo.*/
    }
    printf("Nodo parte 3 listo.\n");
    return nuevo_nodo; /*Se retorna el nodo creado, que puede ser guardado como una variable con otro nombre.*/
}

void touch(Nodo* actual, char* nombre_archivo){ /*Función que crea un archivo y lo agrega como hijo de la lista del directorio actual.*/
    Nodo* nuevo_nodo = crear_nodo(actual, "Archivo", nombre_archivo); /*Se crea un nodo que servirá para apuntar al archivo que se creará.*/
    Directorio* dir = (Directorio*) (actual->contenido); /**/
    insertar_lista(dir->hijos, nuevo_nodo); /*Se toma el nodo que apunta al archivo y se inserta en la lista del directorio del nodo actual (asumiendo que este nodo es de tipo directorio).*/
}

void mkdir(Nodo* actual, char* nombre_directorio){ /*Función que crea un directorio y lo agrega a la lista del directorio actual. Funciona de manera similar al touch.*/
    Nodo* nuevo_nodo = crear_nodo(actual, "Directorio", nombre_directorio); /*Se crea un nodo que servirá para apuntar al directorio que se creará.*/
    Directorio* dir = (Directorio*) (actual->contenido);
    insertar_lista(dir->hijos, nuevo_nodo->contenido); /*Se toma el nodo que apunta al directorio y se inserta en la lista del directorio del nodo actual (asumiendo que este nodo es de tipo directorio).*/
}

void ls(Nodo* actual){ /*Función que permite mostrar por pantalla/consola todos los contenidos del directorio actual.*/
    if(strcmp(actual->tipo, "Directorio") == 0){ /*Revisa si el nodo actual es de tipo directorio para poder recorrer su lista.*/
        printf("Se entró a la función.\n");
        Directorio* directorio = (Directorio*)(actual->contenido); /*Se hace un casteo para asegurarse que funcione el recorrido.?*/
        Nodo* recorredor; /*Se llama a un nodo que se utilizara para poder recorrrer la lista del directorio*/
        for(int i = 0; i < (directorio->hijos->largo_actual); i++){ /*Ciclo para recorrer e imprimir los contenidos de la lista del directorio.*/
            printf("Se entró al ciclo.\n");
            recorredor = &(directorio->hijos->arreglo[i]); /*La direccion del puesto actual de la lista del directorio.*/
            if(strcmp(recorredor->tipo,"Archivo") == 0){ /*Revisa si el tipo de contenido que tiene la posición actual es de tipo archivo.*/
                printf("Se entró al if1.\n");
                Archivo* printear = ((Archivo*)actual->contenido); /*Se crea variable para poder imprimir por pantalla, con un casteo para asegurarse.*/
                printf("%s\n",printear->nombre); /*Se imprime por pantalla el nombre del archivo (con un caracter extra al principio para diferencia) en la posicion actual.*/

            } else if(strcmp(actual->tipo,"Directorio") == 0){ /*Revisa si el tipo de contenido que tiene la posición actual es de tipo directorio.*/
                printf("Se entró al if2.\n");
                Directorio* printear = ((Directorio*)actual->contenido); /*Se crea variable para poder imprimir por pantalla, con un casteo para asegurarse.*/
                printf("%s\n./", printear->nombre); /*Se imprime por pantalla el nombre del directorio en la posicion actual.*/
            }
        }
    }
    else{ /*Si el nodo no es de tipo directorio simplemente se avisa por la terminal.*/
        printf("No es posible realizar esta acción.\n"); /*Aviso por terminal.*/
    }
}

void ls_dir(Nodo* actual, char* nombre_directorio){ /*Función que permite mostrar por pantalla/consola todos los contenidos del directorio especifico.*/
    if(strcmp(actual->tipo, "Directorio") == 0){ /*Revisa si el nodo actual es de tipo directorio para poder recorrer su lista.*/
        Directorio* directorio = (Directorio*)(actual->contenido); /*Se hace un casteo para asegurarse que funcione el recorrido.?*/
        Nodo* recorredor; /*Se llama a un nodo que se utilizara para poder recorrrer la lista del directorio*/
        for(int i = 0; i < (directorio->hijos->largo_actual); i++){ /*Ciclo para recorrer e imprimir los contenidos de la lista del directorio.*/
            recorredor = &(directorio->hijos->arreglo[i]); /*La direccion del puesto actual de la lista del directorio.*/
            if(strcmp(directorio->nombre, nombre_directorio) == 0){ /*Se revisa si el nombre del directorio actual coincide con el que se busca, si no coincide no se imprime nada.*/
                if(strcmp(actual->tipo,"Archivo") == 0){ /*Revisa si el tipo de contenido que tiene la posición actual es de tipo archivo.*/
                    Archivo* printear = ((Archivo*)actual->contenido); /*Se crea variable para poder imprimir por pantalla, con un casteo para asegurarse.*/
                    printf("%s\n", printear->nombre); /*Se imprime por pantalla el nombre del archivo (con un caracter extra al principio para diferencia) en la posicion actual.*/

                } else if(strcmp(actual->tipo,"Directorio") == 0){ /*Revisa si el tipo de contenido que tiene la posición actual es de tipo directorio.*/
                    Directorio* printear = ((Directorio*)actual->contenido); /*Se crea variable para poder imprimir por pantalla, con un casteo para asegurarse.*/
                    printf("%s\n", printear->nombre); /*Se imprime por pantalla el nombre del directorio en la posicion actual.*/
                }
            } else{ /*Si el nodo no es de tipo directorio simplemente se avisa por la terminal.*/
                printf("No es posible realizar esta acción en este directorio.\n"); /*Aviso por terminal.*/
            }
        }
    }
}

void cat(Nodo* actual, char* nombre_archivo){ /*Funcion que busca un archivo y muestra su contenido por pantalla. Intenté implementarlo de manera similar a la funcion ls.*/
    if(strcmp(actual->tipo, "Directorio") == 0){ /*Revisa si el nodo actual es de tipo directorio para poder recorrer su lista.*/
        Directorio* directorio = (Directorio*)(actual->contenido); /*Se hace un casteo para asegurarse que funcione el recorrido.?*/
        Nodo* recorredor; /*Se llama a un nodo que se utilizara para poder recorrrer la lista del directorio*/
        for(int i = 0; i < (directorio->hijos->largo_actual); i++){ /*Ciclo para recorrer la lista del directorio.*/
            recorredor = &(directorio->hijos->arreglo[i]); /*La direccion del puesto actual de la lista del directorio.*/
            if(strcmp(actual->tipo, "Archivo") == 0){ /*Revisa si el contenido en la posicion actual es de tipo archivo.*/
                Archivo* printear = (Archivo*)(actual->contenido);
                if(strcmp(printear->nombre,nombre_archivo) == 0){ /*Condicion que compara si el nombre del archivo actual coincide con el char recibido*/
                    /*Archivo* printear = ((Archivo*)actual->contenido); /*Se crea variable para poder imprimir por pantalla, con un casteo para asegurarse.*/
                    printf("%s\n", printear->contenido); /*Se imprime por pantalla el contenido del archivo al encontrar el match.*/
                }
            }
        }
    }
    else{ /*Si el nodo no es de tipo directorio no se puede hacer.*/
        printf("No es posible realizar esta acción.\n");
    }
}

void write(Nodo* actual, char* nombre_archivo, char* contenido){
    if(strcmp(actual->tipo, "Directorio") == 0){ /*Revisa si el nodo actual es de tipo directorio para poder recorrer su lista.*/
        Directorio* directorio = (Directorio*)(actual->contenido); /*Se hace un casteo para asegurarse que funcione el recorrido.?*/
        Nodo* recorredor; /*Se llama a un nodo que se utilizara para poder recorrrer la lista del directorio*/
        for(int i = 0; i < (directorio->hijos->largo_actual); i++){ /*Ciclo para recorrer la lista del directorio.*/
            recorredor = &(directorio->hijos->arreglo[i]); /*La direccion del puesto actual de la lista del directorio.*/
            if(strcmp(actual->tipo, "Archivo") == 0){ /*Revisa si el contenido en la posicion actual es de tipo archivo.*/
                Archivo* archivo = (Archivo*)(actual->contenido); /*Variable para simplificar la condicion que sigue.*/
                if(strcmp(archivo->nombre,nombre_archivo) == 0){ /*Condicion que compara si el nombre del archivo actual coincide con el char recibido*/
                    strcpy(archivo->contenido, contenido); /*Si coincide, se hace un simple string copy del contenido recibido al contenido del archivo que se buscaba.*/
                }
            }
        }
    } else{ /*Si el nodo no es de tipo directorio no se puede hacer.*/
        printf("No es posible realizar esta acción.\n");
    }
}