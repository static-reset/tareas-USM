/*void mostrar_contenido(Nodo* n){
    if(strcmp(n->tipo, "numero") == 0){
        int contenido_real = *((int*)n->contenido);
        printf("%d\n", contenido_real);
    } else if(!strcmp(n->tipo, "caracter")){
        char contenido_real = *((char*)n->contenido);
        printf("Caracter = %c\n", contenido_real);
    }
}*/
