Nombre: Cristobal Andrés Pino Poblete
Rol: 202104597-k

Siempre se crea un nodo padre al inicio para facilitar el programa y su desarrollo (esa era la idea).
Si es necesario de saber, algunas funciones como "ls" le hacen saber al usuario si no se puede ejecutar el comando en sí debido al contenido del nodo. Solo se menciona para que se tenga en cuenta otros casos al momento de ejecutar el programa.
Hice 4 funciones más (ls_dir, mkdir, write, cat) pero sin mucho tiempo para probarlas, de todos modos incluí la manera que pensaba implementarlas y el pensamiento detras de cada linea.
touch y ls funcionan solo en el input, luego existe error de segmentación y por temas de tiempo y pruebas no pude arreglar mucho.