package tarea3;
public class Equipamiento extends Item{

    private String tipo;
    private Integer str;
    private Integer intel;

    Equipamiento(char representacion, String nombre, String tipo, Integer str, Integer intel){
        super(representacion, nombre);
        this.tipo = tipo;
        this.str = str;
        this.intel = intel;
    };

    public String getTipo(){
    	return this.tipo;
    };

    public Integer getStr(){
    	return this.str;
    };

    public Integer getInt(){
    	return this.intel;
    };

    public char getRepresentacion(){
        super.setRepresentacion('E');
        super.getRepresentacion();
    };

};