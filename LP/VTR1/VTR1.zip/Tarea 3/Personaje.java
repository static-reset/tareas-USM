package tarea3;

public class Personaje implements Visible{ /*Clase que construye a el personaje del jugador como a los enemigos, implementando la interfaz visible para su uso en el mapa.*/

    private Float hp; /*Flotante que indica vida disponible del personaje.*/
    private Integer nivel; /*Entero que indica el nivel actual del personaje.*/

    public Integer getNivel(){ /*Metodo que permite saber el nivel actual del personaje.*/
        return nivel; /*Retorna un entero que indica el nive actual del personaje.*/
    };

    public void setNivel(Integer numero){ /*Metodo para indicar el nivel exacto del personaje. Recibe un entero.*/
        this.nivel = numero; /*Se define el nivel del personaje al igualarlo con el valor del entero que se recibe.*/
    };

    public Float getHP(){ /*Metodo que permite saber la vida actual del personaje.*/
        return hp; /*Retorna un flotante de la vida actual del personaje.*/
    };

    Personaje(Float hp, Integer nivel){ /*Constructor para un personaje de cualquier tipo. Tiene que recibir un flotante para la vida y un entero para el nivel deseado.*/
        this.hp = hp; /*Se define la vida maxima del personaje con el flotante que se recibe.*/
        setNivel(nivel); /*Se define el nivel del personaje con el metodo de tipo setter.*/
    };

    public char getRepresentacion(){ /*Metodo para obtener la representacion del personaje en el mapa.*/
        return 'O'; /*Retorna un caracter que indica la existencia de un personaje en el mapa.*/
    };

    public void recibirDanio(Float dmg){ /*Metodo que sirve para recibir daño de otro personaje y disminuir la vida del personaje.*/
    	this.hp -= dmg; /*Se le resta al valor de la vida del personaje con el valor del daño recibido.*/
    	if(this.hp <= 0){ /*Condicional que sirve si la vida del personaje alcanza o supera el 0.*/
        	System.out.println("El personaje ha muerto."); /*Se indica por pantalla que el personaje ha muerto.*/
        }
    };

    public Float calcularAtaque(){ /*Metodo que permite calcular el ataque del personaje basado en su nivel actual.*/
    	float cantDanio = 3 * getNivel(); /*Flotante del daño que causa el personaje, calculado con la formula de 3 por el nivel actual del personaje.*/
    	return cantDanio; /*Retorna el valor del daño que puede causar el  personaje.*/
    };

    public Integer calcXP(){ /*Metodo que permite calcular la experiencia que gana el personaje. Basado en como se calcula el xp en Disgea.*/
        int xpAlt = (int) (0.04 * Math.pow(getNivel(), 3) + 0.8 * Math.pow(getNivel(), 2) + 2 * getNivel()); /*Variable de tipo entero que se calcula gracias a la formula de curva de XP y nivel en Disgea.*/
        return xpAlt; /*Retorna el valor del XP ganado por el personaje.*/
    };

}