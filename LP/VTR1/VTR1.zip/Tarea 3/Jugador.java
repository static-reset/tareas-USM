package tarea3;
import java.util.*;
import java.lang.Math;

public class Jugador extends Personaje{ /*Clase para crear al personaje que sera controlado exclusivamente por el jugador.*/
    private String nombre; /*String que indica el nombre del jugador.*/
    private Integer xp; /*Experiencia actual del jugador.*/
    private List<Item> inventario; /*Inventario que almacena todos los items que recoge el jugador, de manera desordenada.*/
    private Map<String, Equipamiento> equipamiento = new HashMap<String,Equipamiento>(); /*Mapa de hasheo, para indicar el equipamiento actual del jugador. Se define con llave (tipo de equipamiento) y nombre del equipamiento para su identificacion.*/
    private Arma arma; /*Arma equipada actualmente por el jugador.*/

    public String getNombre(){ /*Metodo para saber el nombre del jugador.*/
        return nombre; /*Retorna al usuario el nombre del jugador.*/
    };

    public Integer getXP(){ /*Metodo para saber la experiencia actual del jugador.*/
        return xp; /*Retorna un entero con la experiencia del jugador.*/
    }

    public String getArmaNombre(){ /*Metodo para saber el nombre del arma equipara por el jugador.*/
        return this.arma.getNombre(); /*Retorna un string del nombre del arma del jugador.*/
    };

    public void addItem(Item item){ /*Metodo para añadir cualquier item al inventario del jugador.*/
        inventario.add(item); /*Se añade el item recogido por el jugador a la lista.*/
        System.out.print("El item "+ item.getNombre() +" se ha añadido a tu inventario."); /*Se le confirma al jugador por pantalla la inclusion del item en su inventario.*/
    };

    Jugador(Float hp, Integer nivel, String nombre){ /*Constructor del jugador. Recibe la cantidad de vida maxima, su nivel de incio y su nombre.*/
        super(hp, nivel); /*Se llama a la variable del padre de esta clase y se usan el flotante y entero recibidos para su constructor.*/
        this.nombre = nombre; /*Se define el nombre del jugador con el string recibido.*/
        this.xp = 0; /*El jugador inicia con 0 experiencia.*/
        Arma basic_esp = new Arma('A', "Espada Basica", 0.5f, 0.25f); /*Se construye la espada básica, un item de tipo arma.*/
    };

    public char getRepresentacion(){ /*Metodo para saber la representacion del item en el mapa*/
    	return 'J'; /*Retorna un caracter para indicar al jugador en el mapa.*/
    };
    
    public void ganarXp(Integer xp){ /*Metodo para subir de XP*/
    	this.xp += xp; /*Se le suma a la XP del jugador el entero recibido.*/
    	if(this.xp >= 100){ /*Condicional por si el jugador supera el valor de 100 XP*/
            Integer nivel_nuevo = getNivel() += 1; /*Se aumenta el nivel actual por 1.*/
            setNivel(nivel_nuevo); /*Se aumenta el nivel actual usando el metodo de Personaje.*/
            this.xp = 0; /*Se reinicia la cantidad de XP del jugador.*/
        };

    };

    public void equipar(Arma arma){
        this.arma = arma;
        System.out.println("El arma "+ arma.getNombre() +" ha sido equipada.");
    };

    public void equipar(Equipamiento equip){
        String tipo = equip.getTipo();
        this.equipamiento = new HashMap<>();
        this.equipamiento.put(tipo, equip);
        System.out.println("El equipamiento "+ equip.getNombre() +" ha sido equipado.");
    };

    public float calcularAtaque(Arma arma){
        float cantDanio = 3 * (getNivel() + arma.calcularAtaque(arma.getMulStr(), arma.getMulIntel()));
        return cantDanio;
    };

    public List<Item> mostrarInventario(){
        System.out.print("--Inventario--");
        System.out.print("[");
        for(Inventario inv : this.inventario){
            System.out.print(inv.toString() + ", ");
        }
        System.out.print("]\n");
    };

    public void mostrarEquip(){
        for(Map.Entry mp: equipamiento.entrySet()){
            System.out.print(mp.getKey()+" "+mp.getValue());
        };
    };

    public void mostrarStats(Jugador jugador){
        System.out.println("---Estadisticas---");
        System.out.println("Nombre: "+ jugador.getNombre());
        System.out.println("Nivel: "+ jugador.getNivel());
        System.out.println("HP: "+ jugador.getHP());
        System.out.println("Ataque: "+ jugador.calcularAtaque());
        System.out.println("Equipamiento: "); 
        jugador.mostrarEquip();
        System.out.println("Arma: "+ jugador.getArmaNombre() +".");
    };

};