package tarea3;
public class Arma extends Item{

    private Float mul_str;
    private Float mul_intel;

    Arma(char representacion, String nombre, Float mul_str, Float mul_intel){
        super(representacion, nombre);
        this.mul_str = mul_str;
        this.mul_intel = mul_intel;
    };

    public Float getMulStr(){
        return this.mul_str;
    };

    public Float getMulIntel(){
        return this.mul_intel;
    };

    public char getRepresentacion(){
        super.setRepresentacion('A');
        super.getRepresentacion();
    };

    /*Usar instanceof para checkear en Item si es Arma o Equipamiento.*/

    public Float calcularAtaque(Float str,Float intel){
        Float ataque = (mul_str*str)+(mul_intel*intel);
        return ataque;
    };

}