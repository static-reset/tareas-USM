package tarea3;
interface Visible{ /*Interfaz que funciona como una clase abstracta y publica, para poder representar los elementos del juego en el mapa.*/

    char getRepresentacion(); /*Variable publica y con funcionamiento indefinido, que entrega al mapa un caracter para representar al elemento del juego.*/

}