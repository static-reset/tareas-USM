package tarea3;

public abstract class Item implements Visible{ /*Clase de tipo abstracta que sirve para crear items en el mundo. Puede ser de 2 tipos distintos.*/

    private char representacion; /*Caracter que define cual tipo de item es exactamente.*/
    private String nombre; /*Nombre del item.*/

    public String getNombre(){ /*Obtiene el nombre del item en cuestion.*/
        return this.nombre; /*Retorna al usuario un string que contiene el nombre del item.*/
    };

    public char setRepresentacion(char variable){ /*Recibe un caracter que se usará para representar al item en el mapa. Se definira de manera mas especifica dependiendo del tipo de item.*/
        this.representacion = variable; /*Define la representacion del item usando el caracter recibido.*/ 
    };

    public char getRepresentacion(){ /*Obtiene el caracter para representar al item en el mapa.*/
        return representacion; /*Retorna al usuario un caracter del tipo de item que es.*/
    };

    Item(char representacion, String nombre){ /*Constructor del item. Recibe un caracter para su representacion y un string para definir su nombre.*/
        this.nombre = nombre; /*Define el nombre con la string que se recibe.*/
        setRepresentacion(representacion); /*Define la representacion exacta del item para el mapa.*/
    }

    /*public void randItem(float rand){ /*Metodo para generar un item de manera aleatoria, usando un flotante y viendo si es par o impar.*/
        /*Item item; /*Definicion inicial del item.*/
        /*if(rand/2 == 0){ /*Si el flotante es par...*/
            /*item = new Arma(getRepresentacion(), getNombre() 5.0, 5.0);
        } else{
            item = new Equipamiento(getRepresentacion(), getNombre(), "pechera", 5, 5);
        }
    };*/

    

}