package tarea3;
import java.util.*;

public class JavaHack{
	public static void main(String[] args){ /*Definicion de la clase que va a servir como el programa principal para el juego.*/
		/*Inicializacion del juego.*/
		Scanner in = new Scanner(System.in); /*Clase que nos permite la lectura de datos primitivos entregados por el usuario.*/
		System.out.println("Introduzca un nombre para su personaje: ");
		String nombre = in.nextLine(); /*Se recibe el nombre ingresado por el usuario en consola.*/
		Jugador jugador = new Jugador(100f , 1, nombre); /*Aqui se construye el jugador, con los datos entregados por el PDF y el usuario.*/
		System.out.println("Indique el largo del mundo a crear: ");
		Integer inAlto = in.nextInt(); /*Se recibe el largo de la primera lista para el mapa, que servira como el alto.*/
		System.out.println("Indique el ancho del mundo a crear: ");
		Integer inAncho = in.nextInt(); /*Se recibe el largo de la segunda lista para el mapa, que servira como el ancho.*/
		Mundo mundo = new Mundo(inAlto, inAncho); /*Aqui se construye el mundo, con los datos entregados por el usuario.*/
		System.out.println("Inicializando JavaHack....");
		/*Sistema principal del juego y los turnos.*/
		Boolean turno = true; /*Variable para mantener el bucle activo mientras el personaje del jugador siga vivo.*/
		Integer pos_lat = 0, pos_ver = 0; /*Variables que serviran como referencia para el movimiento y posicion del jugador en el mapa.*/
		while(turno == true){ /*Bucle de tipo while, que se mantendrá activo hasta que el personaje del jugador muera.*/
			mundo.mostrar(); /*Se imprime por pantalla el mundo generado, con las letras indicando la existencia de enemigos y posibles items.*/
			System.out.println("1. Estadisticas.\n2. Mover.\n3. Inventario.\n4. Siguiente Nivel.\n\nIndique su siguiente acción: "); /*Menú para el jugador.*/
			Integer opcion = in.nextInt(); /*Se recibe la accion decidida por el jugador.*/
			if(opcion == 1){ /*Se mostrarán las estadisticas del jugador.*/
				jugador.mostrarStats(jugador); /*Funcion que obtiene los datos privados del jugador y los imprime por consola.*/
			} else if(opcion == 2){ /*El personaje del jugador se mueve.*/
				System.out.println("1. Derecha; 2. Izquierda; 3. Arriba; 4. Abajo"); /*Guia de opciones para el movimiento (solo de tipo adyacente).*/
				System.out.println("Indique hacia donde desea desplazarse (solo posiciones adyacentes): ");
				Integer pos_in = in.nextInt(); /*Se recibe la accion de movimiento decidida por el jugador.*/
				if(pos_in == 1){ /*Si se mueve a la derecha...*/
					if(pos_lat == mundo.getAncho()-1) pos_lat = -1; /*Condicional que se asegura que el jugador no salga del mapa.*/
					pos_lat += 1; /*Se actualiza la posicion del jugador a la derecha.*/
				} else if(pos_in == 2){ /*Si se mueve a la izquierda...*/
					if(pos_lat == 0) pos_lat = mundo.getAncho(); /*Condicional que se asegura que el jugador no salga del mapa.*/
					pos_lat -= 1; /*Se actualiza la posicion del jugador a la izquierda.*/
				} else if(pos_in == 3){ /*Si se mueve hacia arriba...*/
					if(pos_ver == 0) pos_lat = mundo.getAlto(); /*Condicional que se asegura que el jugador no salga del mapa.*/
					pos_ver -= 1; /*Se actualiza la posicion del jugador hacia arriba.*/
				} else if(pos_in == 4){ /*Si se mueve hacia abajo...*/
					if(pos_ver == mundo.getAlto()-1) pos_lat = -1; /*Condicional que se asegura que el jugador no salga del mapa.*/
					pos_ver += 1; /*Se actualiza la posicion del jugador hacia abajo.*/
				};
				/*if((mundo.getValuePosMapa() = 'A'){
					Item item = new Item();
					item.randItem(mundo.getValuePosMapa());*/
				/*} else if(mundo.getValuePosMapa() = 'E')){ /*Por si se encuentra un item en la posicion actual del jugador al moverse.*/
					/*Item randItem(mundo.getValuePosMapa()); /*Declaracion de variable para generar un item aleatorio.*/
					/*jugador.addItem(randItem);*/ /*Se añade el item al inventario del jugador, independiente de su tipo.*/
				} else if(mundo.getValuePosMapa() = 'O'){ /*Encuentro con algún enemigo.*/
					Personaje enemigo = new Personaje(75f, mundo.getNivel());  /*Se crea una variable de tipo Personaje, que batallará contra el jugador hasta que 1 muera.*/
					for(Integer t = 0; t<100; t++){ /*Bucle con un largo generoso para asegurar que alguno de los 2 personajes muera.*/
						if(enemigo.getHP() <= 0){ /*Si el enemigo muere primero...*/
							jugador.ganarXP(enemigo.calcXP()); /*El jugador recibe el XP generado por el enemigo, basado en el calculo de XP por Disgea.*/
							mundo.minCantEnemigos(); /*Se disminuye el contador de enemigos del mapa.*/
							break; /*Se sale del bucle.*/
						} else if(jugador.getHP() <= 0){ /*Si el jugador muere primero...*/
							System.out.println("El jugador ha MUERTO."); /*Se le avisa que su personaje ha muerto.*/
							break; /*Se sale del bucle.*/
							turno = false; /*Como el jugador muere, se rompe el bucle principal del juego.*/
						} else{ /*Si todavia no muere uno...*/
							jugador.recibirDanio(enemigo.calcularAtaque()); /*Se calcula el daño recibido por el jugador.*/
							enemigo.recibirDanio(jugador.calcularAtaque()); /*Se calcula el daño recibido por el enemigo.*/
						};
					};
					
				};

			} else if(opcion == 3){ /*Mostrar el inventario actual.*/
				jugador.mostrarInventario(); /*Se llama a la funcion de presentar el inventario por consola, independiente de su tipo y todo guardado en una llave.*/
			} else if(opcion == 4){ /*Subir el nivel del mundo. Se chequea si cumple con los requisitos del mundo.*/
				if(mundo.getCantEnemigos() == 0){ /*Si se cumple el requisito de haber eliminado a todos los enemigos del mundo...*/
					mundo.nuevoNivel(); /*Se genera un nuevo nivel de mundo, con un mapa completamente nuevo.*/
					pos_ver = 0; pos_lat = 0; /*Se reinicia la posicion del jugador.*/
				} else{ /*Si aun quedan enemigos en el mundo...*/
					System.out.println("Aún quedan enemigos en el mapa."); /*Se le avisa al jugador.*/
				};
			} else{ /*Si se ingresa un numero que no coincide con las opciones presentadas...*/
				System.out.println("Opción incorrecta, por favor ingrese alguna de las opciones presentadas."); /*Se le informa al jugador de su error por pantalla.*/
			};
		};

		in.close(); /*Al terminar el bucle del juego se asegura de cerrar el scanner que recibe inputs del jugador.*/
	};
    
};