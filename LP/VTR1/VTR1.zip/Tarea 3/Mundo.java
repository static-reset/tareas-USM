package tarea3;
import java.util.*;
import java.lang.Math;

public class Mundo{ /*Clase para el mundo del juego*/
    /*Variables privadas.*/
    private Integer nivel; /*Indica el nivel de dificultad del mundo.*/
    private Integer alto; /*Indica el largo de la primera lista del mapa.*/
    private Integer ancho; /*Indica el largo de la segunda lista del mapa.*/
    private Integer enemigos; /*Indica la cantidad de enemigos presentes en el nivel actual.*/
    private List<List<Char>> mapa; /*Arreglo para crear un array 2D, usando las variables de alto y ancho para el largo de cada lista.*/

    /*Metodos para acceder a las variables privadas.*/
    public Integer getNivel(){ /*La obtencion del entero del nivel del mundo.*/
        return nivel; /*Retorna al usuario un entero que indica el nivel actual del mundo.*/
    };
    public Integer getAlto(){ /*Un entero que funciona como el alto del mundo y el largo de la primera lista del mapa.*/
        return alto; /*Retorna al usuario un entero que indica el alto del mundo y el largo de la primera lista del mapa.*/
    };
    public Integer getAncho(){ /*Un entero que funciona como el ancho del mundo y el largo de la segunda lista del mapa.*/
        return ancho; /*Retorna al usuario un entero que indica el ancho del mundo y el largo de la segunda lista del mapa.*/
    };

    public Integer getCantEnemigos(){ /*Un entero que indica la cantidad actual de enemigos en el mapa.*/
        return enemigos; /*Retorna al usuario la cantidad actual de enemigos en el mapa.*/
    };

    public char getValuePosMapa(){ /*El valor de la lista*/
        return mapa.get(getAlto()).get(getAncho());
    };

    public void minCantEnemigos(){ /*Variable para reducir la cantidad de enemigos en el mapa por si muere alguno.*/
        this.enemigos -= 1; /*Reduce la cantidad total de enemigos en el mapa por 1.*/
    };

    public void masCantEnemigos(){ /*Variable para aumentar la cantidad de enemigos en el mapa al generar éste.*/
        this.enemigos += 1; /*Aumenta la cantidad total de enemigos en el mapa por 1.*/
    };

    public static Float randNum(){ /*Genera un numero flotante aleatorio, el cual será usado en la generación del mundo..*/
        Random rand = new Random(); /*Se genera una variable del tipo Random de la clase Math, que puede generar una variable primitiva aleatoria.*/
    	Float ret = rand.nextFloat(); /*Se define una variable flotante, que recibe su valor de manera aleatoria gracias a la variable random*/
        return ret; /*Retorna al usuario el valor flotante aleatorio para la generación del mundo y mapa.*/
	};

	public void generarMapa(){ /*Variable que crea un array 2D del mundo como un mapa. Se insertan de manera aleatoria enemigos e items.*/
        Integer al = getAlto(); Integer an = getAncho();
    	this.mapa = new ArrayList<List<Char>>(getAlto());
        for(Integer i = 0; i < al; i++){
            Personaje enemigo = new Personaje(75, mundo.getNivel());
            List<Char> mapa2 = new ArrayList<Char>(getAncho());
            for(Integer j = 0; j < an; j++){
                if((i == 0) && (j == 0)){
                    Jugador jugador;
                    mapa2.add(jugador.getRepresentacion());
                }
                float r = (randNum());
                if(r <= (Math.min(0.05 + 0.01 * getNivel(),20))){ /*Item aleatorio.*/
                    Item item_rand;
                    if((r/2)==0){
                        item_rand = new Arma('A', "Espada", 2.5f, 1.5f);
                        mapa2.add(item_rand.getRepresentacion());
                    } else{
                        item_rand = new Equipamiento('E', "Pechera Normal", "Armadura", 20, 10);
                        mapa2.add(item_rand.getRepresentacion());
                    };
                    System.out.println("Hay un item aleatorio.");
                } else if(r > (Math.min(0.05f + 0.1f * getNivel(), 20)) && r <= (Math.min(0.2f + 0.01f * getNivel(), 55))){ /*Enemigo*/
                    mapa2.add(enemigo.getRepresentacion());
                    masCantEnemigos();
                    System.out.println("Hay un enemigo.");
                } /*Casilla vacia.*/
            };
            this.mapa.add(mapa2);
        };
    	
    };

    public void mostrar(){ /*Se imprime por pantalla el array 2D que sirve como el mapa del mundo, luego de haber sido generado.*/
        for(Integer i = 0; i<(getAlto()); i++){ /*Bucle del tipo for para la primera lista del mapa.*/
            for(Integer j = 0; j<(getAncho()); j++){ /*Bucle del tipo for para la segunda lista del mapa.*/
                System.out.print(mapa.get(i).get(j) + " | "); /*Se imprime el valor actual de cada lista, con una separacion para hacer visualmente unas casillas.*/
            };
            System.out.print("\n"); /*Salto de linea para seguir con el siguiente valor de la primera lista.*/
        };

    };

    /*Constructor de la clase.*/
    Mundo(Integer alto, Integer ancho){ /*Recibe 2 enteros para la construccion de su mapa y mundo.*/
        this.alto = alto; /*Se define el alto del mundo.*/
        this.ancho = ancho; /*Se define el ancho del mundo.*/
        nivel = 1; /*Al construir un mundo siempre se empieza del primer nivel.*/
        generarMapa(); /*Se genera el mapa al tener todos los datos en lugar.*/
        mostrar(); /*Se muestra el mapa por consola luego de haber generado el mapa.*/
    };

    public void nuevoNivel(){ /*Metodo tipo void que aumenta el nivel del mundo y regenera el mapa.*/
    	this.nivel++; /*Se aumenta el nivel del mundo actual.*/
    	generarMapa(); /*Se genera nuevamente el mapa y los enemigos e items basado en esto.*/
    };

}