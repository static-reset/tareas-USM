Nombre: Cristobal Andrés Pino Poblete
Rol: 202104597-k
RUT: 21.125.616-8

Instrucciones para el programa: extraer todos los archivos en una carpeta y ejecutarlos con la aplicación de DrRacket. Incluyo los casos de prueba del PDF en cada archivo solicitado.