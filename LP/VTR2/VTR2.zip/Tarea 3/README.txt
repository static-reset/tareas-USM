Nombre: Cristobal Andrés Pino Poblete
Rol: 202104597-k
RUT: 21.125.616-8

Instrucciones: al comprimir el archivo .tar.gz, asegurarse de dejar tanto el archivo makefile como la carpeta "Tarea3" en una misma carpeta, pero NO dejar el makefile dentro de la carpeta "Tarea3". Hacer lo contrario resultará en una compilacion erronea y en el mal funcionamiento del paquete de la tarea.

El makefile viene con 3 comandos:
-make compile: compila todos los archivos de tipo .java en la carpeta "Tarea3" y retorna los archivo .class (que nos dará el main).
-make run: ejecuta el archivo Juego.class, el cual actual como el archivo main de la tarea para interactuar con el juego.
-make clean: elimina todos los archivos .class en la carpeta, incluyendo el main. Solo se debe usar luego de haber terminado el juego.

Notas sobre el programa:

-Todas las clases fueron implementadas con constructores, getters, setters y las funciones pedidas.

-Si bien en VSCode puede salir un warning en algunas clases por no cerrar el Scanner, esto no es un problema al compilar ya que en el main se cierra el Scanner al terminar el juego (y con esto se evita problemas de NoSuchElementException).

-Se ha tenido cuidado de avisar cuando una zona ya no está disponible para permitir interacción. Tambien se ha tenido cuidado con la clase Enemigo, para evitar que su ataque deje con una cantidad menor a 0 de Pikinims.

-Siguiendo la misma linea, si se avanza hacia una muralla y no se derriba en el primer intento, la interfaz le informa al usuario por cual lado no puede desplazarse hasta que se logre derribar la muralla.

-El programa intenta presentar la mayor cantidad de información disponible, aunque la interfaz sea básica.

-Se considera como victoria del juego cuando se consigue que las 3 zonas de tipo Piezas tengan su atributo "completada" con valor 'true', siempre y cuando sea dentro de los 30 turnos disponibles.