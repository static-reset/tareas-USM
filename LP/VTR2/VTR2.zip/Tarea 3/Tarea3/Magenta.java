package Tarea3;

/* Clase Magenta que hereda de Pikinim. No contiene campos privados unicos.
 * El constructor recibe un entero que define la cantidad de Pikinims de tipo Magenta deseados. */
public class Magenta extends Pikinim {

    /*Constructor de la clase Magenta. En el constructor se llama al super-constructor de Pikinim, 
    asignando 2 de ataque, 1 de capacidad y la cantidad que se recibe como parametro de Pikinims Magenta. */
    Magenta(Integer cantMagenta){
        super(2, 1, cantMagenta);
    }

    /* Sobrecarga del metodo multiplicar: recibe un entero con la cantidad a multiplicar.
    Para obtener la cantidad de Pikinims Magenta multiplicados se multiplica el parametro de cantidad por el valor de ataque del Pikinim Magenta.
    Este resultado es luego entregado como parametro al super-setter de la clase Pikinim. */
    public void multiplicar(Integer cantidad){
        Integer multMagenta = cantidad * super.getAtaque();
        super.setCantidad(multMagenta);
    }
    
}
