package Tarea3;

/* Clase publica Muralla que hereda de Zona: contiene un atributo unico que indica la vida de esta muralla.
 * El constructor recibe un entero, que solo settea la cantidad de vida que va a tener. Se incluyen los getters y setters apropiados.
 * Contiene un metodo unico llamado TryRomper, que recibe los 3 tipos de Pikinims e intenta reducir la vida de la muralla para destruirla.
 * Además incluye la sobrecarga del metodo Interactuar de la clase padre Zona. */
public class Muralla extends Zona {

    private Integer vida;

    /* Constructor de la clase Muralla. Recibe un entero que se asigna a su unico atributo de vida. */
    Muralla(Integer vida){
        this.vida = vida;
    }

    public Integer getVida(){
        return this.vida;
    }

    public void setVida(Integer vida){
        this.vida = vida;
    }

    /* Metodo de tipo booleano TryRomper: Recibe los 3 tipos de Pikinims y genera una situacion donde se intenta derribar la muralla.
     * Se calcula el ataque total de todos los Pikinims, que considera su respectivo ataque por su cantidad.
     * Si el resultado es mayor o igual a la vida de la muralla, entonces se settea la vida de la muralla a 0, se informa al jugador que se pudo derribar y se retorna un true.
     * En caso contrario, se informa al jugador por consola junto con la vida restante de la muralla y se retorna un false. */
    public Boolean TryRomper(Cyan jugCyan, Magenta magJug, Amarillo amaJug){
        Integer ataque_total = (jugCyan.getAtaque() * jugCyan.getCantidad()) + (magJug.getAtaque() * magJug.getCantidad()) + (amaJug.getAtaque() * amaJug.getCantidad());
        if(getVida() - ataque_total <= 0){
            setVida(0);
        } else{
            setVida(getVida() - ataque_total);
        }
        if(getVida() <= 0){
            System.out.println("¡Se pudo derribar la muralla!");
            return true;
        } else{
            System.out.println("No se pudo derribar la muralla, le queda " + getVida() + " de vida.");
            return false;
        }
    }

    /* Sobrecarga del metodo Interactuar: recibe los 3 tipos de Pikinims y es usado en cuanto se alcanza la zona.
     * Se revisa si al intentar romper la muralla esta fue derribada. Si es así, entonces se cambia el estado de la zona como "completado" o true.
     * En caso contrario, se retorna sin cambios adicionales. */
    public void Interactuar(Cyan cyanJug, Magenta magJug, Amarillo amaJug){
        if(getEstado() == false){
            if(TryRomper(cyanJug, magJug, amaJug) == true){
                super.setEstado(true);
            } else{
                return;
            }
        } else{
            System.out.println("No queda más que hacer en esta zona.");
        }
    }
}
