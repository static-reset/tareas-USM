package Tarea3;

import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;

public class Juego {
    public static void main(String[] argv){

        /* Scanner para recibir input del usuario por consola. */
        Scanner input = new Scanner(System.in);

        /* Se inician los 3 tipos de Pikinim con la cantidad solicitada en el enunciado para cada uno. */
        Cyan pruebaCy = new Cyan(10);
        Magenta pruebaMag = new Magenta(10);
        Amarillo pruebaAma = new Amarillo(10);

        /* Se crean dos listas de arreglos: una de tipo zona que servirá como el mapa que se recorrerá.
         * El segundo será de tipo string, para guardar el nombre de la zona acorde a su posición. */
        ArrayList<Zona> mapa = new ArrayList<Zona>();
        ArrayList<String> nombre_zona = new ArrayList<String>();

        /* Se inician todas las zonas que se piden en el enunciado, con los valores especificos de cada posición.
         * Luego con añadidas al arreglo de mapa y al arreglo de nombres de zona. */
        Pieza pieza1 = new Pieza(50); mapa.add(pieza1); nombre_zona.add("Pieza");
        Enemigo enemigo1 = new Enemigo(130, 20, 25); mapa.add(enemigo1); nombre_zona.add("Enemigo");
        Enemigo enemigo2 = new Enemigo(50, 10 , 15); mapa.add(enemigo2); nombre_zona.add("Enemigo");
        Pildora pildora1 = new Pildora(25); mapa.add(pildora1); nombre_zona.add("Pildora");
        Muralla muralla1 = new Muralla(50); mapa.add(muralla1); nombre_zona.add("Muralla");
        Pieza pieza2 = new Pieza(100); mapa.add(pieza2); nombre_zona.add("Pieza");
        Enemigo enemigo3 = new Enemigo(45, 8, 10); mapa.add(enemigo3); nombre_zona.add("Enemigo");
        Pieza pieza3 = new Pieza(35); mapa.add(pieza3); nombre_zona.add("Pieza");
        Pildora pildora2 = new Pildora(15); mapa.add(pildora2); nombre_zona.add("Pildora");
        Enemigo enemigo4 = new Enemigo(75, 15, 20); mapa.add(enemigo4); nombre_zona.add("Enemigo");
        Muralla muralla2 = new Muralla(150); mapa.add(muralla2); nombre_zona.add("Muralla");

        /* 4 variables enteras para el flujo del juego: la primera es para mantener un conteo de los turnos,
         * la segunda para indicar la posición del jugador en el mapa (con el valor inicial pedido en el enunciado),
         * la tercera guardará el input del usuario para navegar el mapa
         * y la cuarta recuerda el ultimo movimiento del jugador (es decir, si venia de izquierda o derecha). */
        Integer turno;
        Integer posicion_jugador = 6;
        Integer opcion;
        Integer ultimo_mov = 0;
        
        /* El bucle principal del juego. Como parte de las reglas, solo se repite 30 veces el bucle para que el jugador recoga todas las piezas.
         * Si el jugador alcanza a recoger las 3 piezas dentro de los 30 turnos, se le informa por pantalla de su victoria y se termina tanto el bucle como el scanner.
         * Si el jugador no logra recoger las piezas en los 30 turnos, se le informa por pantalla de su derrota y se cierra el programa.
         * Se incluye también la opción de terminar el juego de manera anticipada, al ingresar un input distinto de 1 / 2 / 3.
         */
        for(turno = 1; turno <= 30; turno++){
            if(pieza1.getEstado() == true && pieza2.getEstado() == true && pieza3.getEstado() == true){
                System.out.println("¡Se han conseguido todas las piezas de la nave!");
                System.out.println("El capitán Lomiar ha podido escapar del planeta y sigue su aventura. ¡Felicidades!");
                break;
            }
            System.out.println("----------------------------------------");
            System.out.println("Turno " + turno + " (Cyan - " + pruebaCy.getCantidad() + ", Amarillo - " + pruebaAma.getCantidad() + ", Magenta - " + pruebaMag.getCantidad() + ")");
            System.out.println("Piezas recuperadas: " + cant_piezas);
            System.out.print("Zona Actual: " + nombre_zona.get(posicion_jugador-1));
            if(nombre_zona.get(posicion_jugador-1) == "Pieza"){
                System.out.println(" (peso: " + ((Pieza)mapa.get(posicion_jugador-1)).getPeso() + ")");
            } else if(nombre_zona.get(posicion_jugador-1) == "Enemigo"){
                System.out.println(" (vida: " + ((Enemigo)mapa.get(posicion_jugador-1)).getVida() + ", peso: " + ((Enemigo)mapa.get(posicion_jugador-1)).getPeso() + ", ataque: " + ((Enemigo)mapa.get(posicion_jugador-1)).getAtaque() + ")");
            } else if(nombre_zona.get(posicion_jugador-1) == "Pildora"){
                System.out.println(" (cantidad: " + ((Pildora)mapa.get(posicion_jugador-1)).getCantidad() +")");
            } else if(nombre_zona.get(posicion_jugador-1) == "Muralla"){
                System.out.println(" (vida: " + ((Muralla)mapa.get(posicion_jugador-1)).getVida() +")");
            }
            System.out.println("Opciones");
            if(nombre_zona.get(posicion_jugador-1) == "Muralla" && mapa.get(posicion_jugador-1).getEstado() == false){
                if(ultimo_mov == 1){
                    System.out.println("1. No Disponible 2. Ir a izquierda (" + nombre_zona.get(posicion_jugador-2) + ") 3. Quedarse aquí");
                } else if(ultimo_mov == 2){
                    System.out.println("1.  Ir a derecha (" + nombre_zona.get(posicion_jugador) + ") 2. No Disponible 3. Quedarse aquí");
                }
            } else if(posicion_jugador == 11){
                System.out.println("1. Ir a derecha (" + nombre_zona.get(0) + ") 2. Ir a izquierda (" + nombre_zona.get(posicion_jugador-2) + ") 3. Quedarse aquí");
            } else if(posicion_jugador == 1){
                System.out.println("1. Ir a derecha (" + nombre_zona.get(posicion_jugador) + ") 2. Ir a izquierda (" + nombre_zona.get(10) + ") 3. Quedarse aquí");
            } else{
                System.out.println("1. Ir a derecha (" + nombre_zona.get(posicion_jugador) + ") 2. Ir a izquierda (" + nombre_zona.get(posicion_jugador-2) + ") 3. Quedarse aquí");
            }
            System.out.println("----------------------------------------");
            System.out.print("Su input: ");
            opcion = input.nextInt();
            ultimo_mov = opcion;
            if(opcion == 1){
                if(nombre_zona.get(posicion_jugador-1) == "Muralla" && mapa.get(posicion_jugador-1).getEstado() == false && ultimo_mov == 1){
                    System.out.println("La muralla aún no fue derribada, no puede hacer ese movimiento.");
                } else{
                    mapa.get(posicion_jugador).Interactuar(pruebaCy, pruebaMag, pruebaAma);
                    posicion_jugador = posicion_jugador + 1;
                    continue;
                }
            } else if(opcion == 2){    
                if(nombre_zona.get(posicion_jugador-1) == "Muralla" && mapa.get(posicion_jugador-1).getEstado() == false && ultimo_mov == 2){
                    System.out.println("La muralla aún no fue derribada, no puede hacer ese movimiento.");
                } else{
                    mapa.get(posicion_jugador-2).Interactuar(pruebaCy, pruebaMag, pruebaAma);
                    posicion_jugador = posicion_jugador - 1;
                    continue;
                }
            } else if(opcion == 3){
                mapa.get(posicion_jugador-1).Interactuar(pruebaCy, pruebaMag, pruebaAma);
                continue;
            } else{ /* Si el usuario desea terminar el juego en cualquier momento, un input distinto de 1 / 2 / 3 cerrara el scanner y rompera el bucle. */
                input.close();
                break;
            }

        }
        /* Al terminar el bucle se cerrara el scanner. */
        input.close();
        
    }
}
