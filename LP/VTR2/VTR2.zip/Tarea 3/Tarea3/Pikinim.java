package Tarea3;
/* Clase abstracta Pikinim. Incluye getters y setters para los datos de interés.
 * En sus campos privados contiene el valor de ataque, su capacidad máxima y su cantidad actual.
 * El constructor recibe 3 enteros que se asignan a los atributos privados ya mencionados.
 * Presenta el metodo abstracto multiplicar, que es alterado por sus subclases debido a sus formas unicas de calcular como multiplicarse.
 * Además contiene el metodo disminuir, que simplemente reduce la cantidad actual del tipo de Pikinim.
 */
public abstract class Pikinim {
    private Integer ataque;
    private Integer capacidad;
    private Integer cantidad;

    /* Constructor de la clase Zona. */
    Pikinim(Integer ataque, Integer capacidad, Integer cantidad){
        this.ataque = ataque;
        this.capacidad = capacidad;
        this.cantidad = cantidad;
    }

    public void disminuir(Integer cantidad){
        this.cantidad -= cantidad;
    };

    public void multiplicar(Integer cantidad){};

    public Integer getAtaque(){
        return this.ataque;
    }

    public Integer getCapacidad(){
        return this.capacidad;
    }

    public Integer getCantidad(){
        return this.cantidad;
    }

    public void setCantidad(Integer cantidad){
        this.cantidad = cantidad;
    }

}
