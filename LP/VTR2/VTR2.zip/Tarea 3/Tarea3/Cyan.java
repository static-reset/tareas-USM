package Tarea3;

/* Clase Cyan que hereda de Pikinim. No contiene campos privados unicos.
 * El constructor recibe un entero que define la cantidad de Pikinims de tipo Cyan deseados. */
public class Cyan extends Pikinim {

    /* Constructor de la clase Cyan. En el constructor se llama al super-constructor de Pikinim, 
    asignando 1 de ataque y capacidad y la cantidad que se recibe como parametro de Pikinims Cyan. */
    Cyan(Integer cantCyan){
        super(1, 1, cantCyan);
    }
    /* Sobrecarga del metodo multiplicar: recibe un entero con la cantidad a multiplicar.
    Para obtener la cantidad de Pikinims Cyan multiplicados se multiplica el parametro de cantidad por 3.
    Este resultado es luego entregado como parametro al super-setter de la clase Pikinim. */
    public void multiplicar(Integer cantidad){
        Integer multCyan = cantidad * 3;
        super.setCantidad(multCyan);
    }
    
}
