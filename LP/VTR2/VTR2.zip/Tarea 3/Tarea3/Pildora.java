package Tarea3;

import java.util.Scanner;
import java.lang.Math;

/* Clase publica Pildora, que hereda de la clase Zona: contiene solo un atributo unico que indica la cantidad de pildoras.
 * El constructor de la clase recibe un solo entero que se settea al atributo de cantidad de pildoras. Se incluye el getter apropiado.
 * Solo contiene una sobrecarga del metodo Interactuar de la clase padre Zona. */
public class Pildora extends Zona {

    private Integer cantidad;

    /* Constructor de la clase Pildora. Recibe un entero que es asigno al atributo de cantidad de pildoras. */
    Pildora(Integer cantidad){
        this.cantidad = cantidad;
    }

    public Integer getCantidad(){
        return this.cantidad;
    }

    /* Sobrecarga del metodo Interactuar: recibe los 3 tipos de Pikinims y ofrece al jugador la posibilidad de multiplicar gratuitamente alguno de los Pikinims.
     * Se le informa al jugador la cantidad de pildoras disponibles, que seran usadas como parametro al llamar al metodo multiplicar del tipo de Pikinim elegido.
     * Al terminar de multiplicar los Pikinims e informar al jugador de la cantidad obtenida, se marca la zona como "completada" o true.
     * Se llama a este metodo en cuanto el usuario alcanza la zona al moverse por el mapa. */
    public void Interactuar(Cyan cyanJug, Magenta magJug, Amarillo amaJug){
        if(getEstado() == false){
            Scanner input = new Scanner(System.in);
            Integer cant_total_Pikinim = cyanJug.getCantidad() + magJug.getCantidad() + amaJug.getCantidad();
            System.out.println("\nLomiar llegó a un lugar lleno de unas figuras con forma de píldoras, los " + cant_total_Pikinim + " Pikinim se llevan las pildoras");
            System.out.println("Qué color de pikinim desea que se multiplique? (cantidad a multiplicar: " + getCantidad() + ")");
            System.out.println("1. Cyan 2. Magenta 3. Amarillo");
            Integer eleccion = input.nextInt();
            if(eleccion == 1){
                cyanJug.multiplicar(getCantidad());
                System.out.println("Input: " + eleccion + "");
                System.out.println("Los Pikinim cyan han aumentado su cantidad en " + (getCantidad() * 3));
            } else if(eleccion == 2){
                magJug.multiplicar(getCantidad());
                System.out.println("Input: " + eleccion + "");
                System.out.println("Los Pikinim magenta han aumentado su cantidad en " + (getCantidad() * magJug.getAtaque()));
            } else if(eleccion == 3){
                amaJug.multiplicar(getCantidad());
                System.out.println("Input: " + eleccion + "");
                Double aumento = (getCantidad() * 1.5);
                Integer valor_aumento = aumento.intValue();
                System.out.println("Los Pikinim amarillos han aumentado su cantidad en " + valor_aumento);
            }
            super.setEstado(true);
        } else{
            System.out.println("No queda más que hacer en esta zona.");
        }
    }
    
}
