package Tarea3;

/* Clase publica Pieza, que hereda de Zona e implementa la interfaz ILevantar:
 * contiene un atributo unico que indica el peso de la pieza.
 * El constructor recibe un entero que solo se encarga de settear su peso. Se incluyen el getter apropiado.
 * Solo contiene sobrecargas de los metodos Levantar e Interactuar, que provienen de la interfaz ILevantar y la clase padre Zona respectivamente. */
public class Pieza extends Zona implements ILevantar {
    private Integer peso;

    /* Constructor de la clase. Recibe un solo entero que se asigna al atributo de peso. */
    Pieza(Integer peso){
        this.peso = peso;
    }

    public Integer getPeso(){
        return this.peso;
    }

    /* Sobrecarga de metodo Levantar: recibe los 3 tipos de Pikinims y revisa si es posible levantar la pieza para progresar hacia la victoria del juego.
     * Si la suma de la cantidad por la cantidad de todos los Pikinims disponibles es mayor que el peso de la pieza, esta será levantada y el estado de la zona se cambiará a "completado".
     * En caso contrario, se le informará al jugador que no se pudo recuperar la pieza y se pasa al siguiente turno. */
    public void Levantar(Cyan cyanJug, Magenta magJug, Amarillo amaJug){
        Integer fuerza_total = (cyanJug.getCantidad() * cyanJug.getCapacidad()) + (magJug.getCantidad() * magJug.getCapacidad()) + (amaJug.getCantidad() * amaJug.getCapacidad());
        if(fuerza_total >= getPeso()){
            System.out.println("¡Se ha recuperado un tesoro!");
            super.setEstado(true);
        } else{
            System.out.println("No se ha podido recuperar el tesoro.");
            return;
        }
    }

    /* Sobrecarga de metodo Interactuar: recibe los 3 tipos de Pikinims y llama a la función Levantar.
     * Se llama a este metodo en cuanto el jugador alcance la zona. */
    public void Interactuar(Cyan cyanJug, Magenta magJug, Amarillo amaJug){
        if(getEstado() == false){
            Levantar(cyanJug, magJug, amaJug);
        } else{
            System.out.println("No queda más que hacer en esta zona.");
        }
    }
}
