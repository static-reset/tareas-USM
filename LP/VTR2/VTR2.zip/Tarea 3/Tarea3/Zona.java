package Tarea3;

/* Clase public Zona: solo presenta un atributo de tipo booleano, que indica si la zona fue completada o no.
 * El constructor no recibe nada, solo sirve para setear. Se incluyen setters y getters.
 * Presenta un metodo void vacio, que será redefinido y sobrecargado por sus subclases. */
public class Zona {

    private Boolean completada;
    /* Constructor de la clase Zona. */
    Zona(){
        this.completada = false;
    };

    /* Metodo void Interactuar, recibe 3 tipos de Pikinims. */
    public void Interactuar(Cyan cyanJug, Magenta magJug, Amarillo amaJug){
    };

    public void setEstado(Boolean estado){
        this.completada = estado;
    }

    public Boolean getEstado(){
        return this.completada;
    }
    
}
