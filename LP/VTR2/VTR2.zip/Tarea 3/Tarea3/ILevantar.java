package Tarea3;

/* Interfaz ILevantar
 * Presenta un unico metodo llamado Levantar, que recibe como parametro los 3 tipos de Pikinims disponibles.
 * Al ser una interfaz, sus metodos son vacios y pensados para ser redefinidos por las clases que la implementen. */
public interface ILevantar {
    public void Levantar(Cyan pikCyan, Magenta pikMag, Amarillo pikAma);
}