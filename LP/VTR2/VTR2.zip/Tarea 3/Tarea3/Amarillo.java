package Tarea3;
import java.lang.*;

/* Clase Amarillo que hereda de Pikinim. No contiene campos privados unicos.
 * El constructor recibe un entero que define la cantidad de Pikinims de tipo Amarillo deseados. */
public class Amarillo extends Pikinim {

    /*Constructor de la clase Amarillo. En el constructor se llama al super-constructor de Pikinim, 
    asignando 1 de ataque, 3 de capacidad y la cantidad que se recibe como parametro de Pikinims Amarillos. */
    Amarillo(Integer cantAmarillo){
        super(1,3,cantAmarillo);
    }

    /* Sobrecarga del metodo multiplicar: recibe un entero con la cantidad a multiplicar.
    Para obtener la cantidad de Pikinims Amarillos multiplicados se multiplica el parametro de cantidad por 1.5, lo cual nos entrega un double.
    Como este resultado no se puede castear de manera tradicional, 
    se crea una variable entera que transforma el resultado como el entero más proximo de ese valor.
    Esta variable es luego entregada como parametro al super-setter de la clase Pikinim. */
    public void multiplicar(Integer cantidad){
        Double cantDouble = cantidad * 1.5;
        Integer multAma = cantDouble.intValue();
        super.setCantidad(multAma);
    }
    
}
