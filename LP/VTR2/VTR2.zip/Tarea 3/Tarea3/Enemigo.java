package Tarea3;

import java.util.Scanner;
import java.lang.Math;

/* Clase publica Enemigo, que hereda de Zona e implementa la interfaz ILevantar:
 * contiene 3 atributos unicos de tipo entero que indican su vida, peso y ataque.
 * El constructor recibe 3 enteros que son asignados a esos atributos respectivamente. Se incluyen los getters y setters apropiados.
 * Contiene un metodo unico llamado Pelear, que recibe los 3 tipos de Pikinims y retorna un booleano que indica si el enemigo fue o no fue derrotado.
 * Tambien incluye sobrecargas de los metodos Interactuar y Levantar, de la clase padre Zona y la interfaz ILevantar respectivamente. */
public class Enemigo extends Zona implements ILevantar{

    private Integer vida;
    private Integer peso;
    private Integer ataque;

    /* Constructor de la clase Enemigo. El constructor recibe 3 enteros que son asignados a sus atributos. */
    Enemigo(Integer vida, Integer peso, Integer ataque){
        this.vida = vida;
        this.peso = peso;
        this.ataque = ataque;
    }

    public Integer getVida(){
        return this.vida;
    }
    
    public Integer getPeso(){
        return this.peso;
    }

    public Integer getAtaque(){
        return this.ataque;
    }

    public void setVida(Integer vida){
        this.vida = vida;
    }

    /* Metodo de tipo booleano Pelear. Recibe los 3 tipos de Pikinims y crea una situación de enfrentamiento entre los 2.
     * Primero atacan los Pikinims, calculando su ataque total (suma de todos los ataques por sus respectivas cantidades),
     * luego ataca el enemigo independiente de cuanto daño recibe. Si el ataque de los Pikinims supera la vida del enemigo,
     * entonces el enemigo tendra su vida setteada a 0 y luego se retorna un true. En caso contrario, se retorna un false. */
    public Boolean Pelear(Cyan cyanJug, Magenta magJug, Amarillo amaJug){
        Integer ataque_total_piknim = (cyanJug.getAtaque() * cyanJug.getCantidad()) + (magJug.getAtaque() * magJug.getCantidad()) + (amaJug.getAtaque() * amaJug.getCantidad());
        Integer resultado_pelea = getVida() - ataque_total_piknim;
        Integer min = 1, max = 3;
        Integer pikinimRand = (int)Math.floor(Math.random() * (max - min + 1) + min);
        if(pikinimRand == 1){
            if(cyanJug.getCantidad() - this.getAtaque() <= 0){
                cyanJug.setCantidad(0);
            } else{
                cyanJug.setCantidad(cyanJug.getCantidad() - this.getAtaque());
            }
        } else if(pikinimRand == 2){
            if(magJug.getCantidad() - this.getAtaque() <= 0){
                magJug.setCantidad(0);
            } else{
                magJug.setCantidad(magJug.getCantidad() - this.getAtaque());
            }
        } else if(pikinimRand == 3){
            if(amaJug.getCantidad() - this.getAtaque() <= 0){
                amaJug.setCantidad(0);
            } else{
                amaJug.setCantidad(amaJug.getCantidad() - this.getAtaque());
            }
        }
        if(resultado_pelea <= 0){
            setVida(0);
            return true;
        } else{
            setVida(resultado_pelea);
            return false;
        }
    }

    /* Sobrecarga de metodo Levantar: Recibe los 3 tipos de Pikinims y revisa si es posible levantar al enemigo para multiplicar Pikinims.
     * Se calcula la capacidad de levantar total de los Pikinims: si este valor es verdadero entonces se permite al usuario escoger
     * alguno de los Pikinims para aumentar su capacidad, informando de la cantidad de Pikinims que se aumentaron En caso contrario,
     * simplementente se retorna Independiente del resultado, al final se cambia el estado de la zona como completado/true. */
    public void Levantar(Cyan cyanJug, Magenta magJug, Amarillo amaJug){
        Integer cap_total = (cyanJug.getCantidad() * cyanJug.getCapacidad()) + (magJug.getCantidad() * magJug.getCapacidad()) + (amaJug.getCantidad() + amaJug.getCapacidad());
        if(cap_total >= getPeso()){
            Scanner input = new Scanner(System.in);
            System.out.println("¡Enhorabuena! Puede multiplicar 1 color de Pikinim. ¿Cual desea multiplicar?");
            System.out.println("1. Cyan 2. Magenta 3. Amarillo");
            System.out.print("Su input: ");
            Integer eleccion = input.nextInt();
            if(eleccion == 1){
                cyanJug.multiplicar(getPeso());
                System.out.println("Los Pikinim Cyan han aumentado su cantidad en " + (getPeso() * 3));
            } else if(eleccion == 2){
                magJug.multiplicar(getPeso());
                System.out.println("Input: " + eleccion + "");
                System.out.println("Los Pikinim Magenta han aumentado su cantidad en " + (getPeso() * magJug.getAtaque()));
            } else if(eleccion == 3){
                amaJug.multiplicar(getPeso());
                System.out.println("Input: " + eleccion + "");
                Double aumento = (getPeso() * 1.5);
                Integer valor_aumento = aumento.intValue();
                System.out.println("Los Pikinim Amarillos han aumentado su cantidad en " + valor_aumento);
            } else{
                return;
            }
        super.setEstado(true);
        }
    }

    /* Sobrecarga de metodo Interactuar: recibe los 3 tipos de Pikinims y es usado en cuanto el usuario alcanza la zona.
     * Se revisa si la pelea resulta con el enemigo siendo derrotado, en ese caso se indica al jugador del resultado y se intenta levantar al enemigo.
     * Si el enemigo no fue derrotado, se le informa al jugador junto con la vida restante del enemigo. */
    public void Interactuar(Cyan cyanJug, Magenta magJug, Amarillo amaJug){
        if(getEstado() == false){
            if(Pelear(cyanJug, magJug, amaJug) == true){
                System.out.println("¡El enemigo fue derrotado!");
                Levantar(cyanJug, magJug, amaJug);
            } else{
                System.out.println("El enemigo no fue derrotado, le queda " + getVida() + " de vida.");
                return;
            }
        } else{
            System.out.println("No queda más que hacer en esta zona.");
        }
    }
    
}
