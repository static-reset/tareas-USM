#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Tablero.h"
#include "Tierra.h"
#include "Bomba.h"

void*** tablero;
int dimension;

void IniciarTablero(int n){
    srand(time(0));
    dimension = n;
    printf("%d", dimension);
    tablero = calloc(dimension, sizeof(void**));
    for(int i = 0; i < dimension; i++){
    //printf("inicio tablero\n");
        tablero[i] = calloc(dimension, sizeof(void*));
    }
    for(int j = 0; j < dimension; j++){
        for(int k = 0; k < dimension; k++){
            Tierra* tierra = (Tierra*)malloc(sizeof(Tierra));
            tierra->vida = (rand() % 3) + 1;
            tierra->es_tesoro = 0;
            tablero[j][k] = tierra;
        }
    }
    printf("fin tablero\n");
    return;
}

void PasarTurno(){
    // Su codigo
    return;
}

void ColocarBomba(Bomba* b, int fila, int columna){
    // Su codigo
    return;
}

void MostrarTablero(){
    printf("fin if\n");
    for(int i = 0; i < dimension; i++){
        for(int j = 0; j < dimension; j++){
            
            if(j == (dimension-1)){
                printf("%d\n",(*(Tierra*)tablero[i][j]).vida);
            }else{
                printf("%d | ",(*(Tierra*)tablero[i][j]).vida);
            }
        }
    }
    return;
}

void MostrarBombas(){
    // Su codigo
    return;
}

void VerTesoros(){
    // Su codigo
    return;
}

void BorrarTablero(void*** tablero){
    for(int i = 0; i < dimension; i++){
        for(int j = 0; j < dimension; j++){
        }
    }
    return;
}
/*
int main(){
    printf("funca\n");
    return 0;
}
*/