#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Tierra.h"
#include "Bomba.h"
#include "Tablero.h"

int main(int argc, char const *argv[]){
    int tamanio;
    printf("¡Bienvenido a TreasureFinder!\n");
    printf("\n");
    printf("Indique el tamaño del tablero a jugar: \n");
    printf("\n");
    printf("1.7x7 2.10x10 3.12x12\n");
    printf("Su input: ");
    scanf("%d", &tamanio);

    if(tamanio == 1){
        tamanio = 7;
    }else if(tamanio == 2){
        tamanio = 10;
    }else if(tamanio == 3){
        tamanio = 12;
    }
   
    IniciarTablero(tamanio);
    printf("fin tablero 2");
    MostrarTablero();
    //BorrarTablero(tablero);
    return 0;
}

/* EJEMPLOS DE RANDOM PARA FACILITAR SU USO.
*
*   srand(time(0)); // Setea la seed del random.
*   int ejemplo_vida = (rand() % 3) + 1; // Obtiene al azar la vida de Tierra a asignar.
*/