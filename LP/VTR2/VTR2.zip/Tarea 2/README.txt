Nombre: Cristobal Andrés Pino Poblete
Rol: 202104597-k
RUT: 21.125.616-8

Instrucciones: guardar todos los archivos .h y .c y el makefile en la misma carpeta donde se desea ejecutar el makefile. Tener cuidado con el directorio a la hora de ejecutar. Para el makefile hay 4 funciones disponibles: 

-make compile / make: se encarga de la compilación de todos los archivos .h, .c; además de los outputs de Tablero y Bomba.
-make run: ejecuta el archivo de salida de TreasureFinder como el programa main de manera directa.
-make runvalgrind: ejecuta TreasureFinder.o y muestra la información de la memoria heap ocupada.
-make remove: elimina los archivos .gch de la carpeta (solo por temas de orden y limpieza).

Notas sobre el programa:

CAMBIO EN STRUCT TIERRA: agregué una variable de tipo entero llamado "hay_bomba". Esta la utilizo para la función "mostrar_tablero()", principalmente para poder mostrar una bomba en el siguiente turno luego de ser plantada. No cambia drásticamente el funcionamiento del código en general, aparte de ser modificada en "borrar_bomba()".

-Si bien fue hecha inicialmente con el objetivo de hacer solamente tableros de 7x7, el programa maneja los tableros de 10x10 y 12x12 de buena manera y con las mismas funciones probadas en 7x7.

-Mi programa puede manejar la variable "tierra_debajo()" sin problemas.

-Las funciones de explosión trabajan bien y se han cubrido la mayoria de casos de posibles errores (segmentation fault,
leaks de memoria y dangling). En particular, me disculpo por el tamaño excesivo de ExplotarX, pero creo que fue necesario
a la hora de evitar situaciones que causarían errores de compilacion/memoria o inconsistencias en el tablero.

-MI PROGRAMA NO CONSIDERA TESOROS. Si bien es una parte integral del juego, sentí que habian otras partes del programa que
necesitaban mayor atención y dedicación (en especial por el control de memoria) por lo que no participa en ninguna faceta del juego (aparte de setear cada variable de tesoro en tierra como 0).