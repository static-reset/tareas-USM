#include "Tierra.h"
#include "Tablero.h"
#include "Bomba.h"
#include <stdlib.h>
#include <stdio.h>

/*
    Funcion TryExplotar:
    Recibe como parametros las coordenadas de la fila y columna en donde se encuentra la bomba.
    Se reduce por 1 el contador de turnos de la bomba, acorde con la pasada del turno, y luego
    se consulta si el contador se agotó. En caso que el contador haya alcanzado 0, se llamará a
    su respectiva función de explotar y luego se borrará la memoria de la bomba para evitar leaks y dangling.
*/
void TryExplotar(int fila, int columna){
    ((Bomba*)tablero[fila][columna])->contador_turnos = ((Bomba*)tablero[fila][columna])->contador_turnos - 1;
    if(((Bomba*)tablero[fila][columna])->contador_turnos <= 0){
        ((Bomba*)tablero[fila][columna])->explotar(fila,columna);
        BorrarBomba(fila, columna);
    }
    return;
}

/*
    Función BorrarBomba:
    Recibe como parametros las coordenadas de la fila y columna en donde se encuentra la bomba.
    Se almacena en un puntero de tipo char la dirección de memoria de la tierra que está debajo de la bomba,
    para evitar su pérdida. Se quita la referencia del puntero tierra_debajo de la bomba y se libera la memoria
    de la bomba. El tablero ahora recibe la dirección de la tierra nuevamente y modifica el indicador
    de la existencia de una bomba sobre ella.
*/
void BorrarBomba(int fila, int columna){
    char* dir_tierra = (char *) (((Bomba*)tablero[fila][columna])->tierra_debajo);
    (((Bomba*)tablero[fila][columna])->tierra_debajo) = NULL;
    free(((Bomba*)tablero[fila][columna]));
    tablero[fila][columna] = dir_tierra;
    (*(Tierra*) tablero[fila][columna]).hay_bomba = 0;
    return;
}

/*
    Funcion ExplosiónPunto:
    Recibe como parametros las coordenadas de la bomba donde se encuentra. Como la bomba es de tipo explosión punto,
    solo se reducirá la vida del tierra en las coordenadas de la bomba. Luego de explotar la bomba, se consulta
    si la vida de la tierra es menor o igual a 0, para mantener una consistencia de resultados e indicar con 0 en
    el tablero que esta tierra ya puede revelar el contenido.
*/
void ExplosionPunto(int fila, int columna){
    ((Bomba*)tablero[fila][columna])->tierra_debajo->vida = ((Bomba*)tablero[fila][columna])->tierra_debajo->vida - 3;
    if(((Bomba*)tablero[fila][columna])->tierra_debajo->vida <= 0){
        ((Bomba*)tablero[fila][columna])->tierra_debajo->vida = 0;
    }
    return;
}

/*
    Función ExplosionX:
    Recibe como parametros las coordenadas de la bomba donde se encuentra ubicada. Como la bomba es de tipo explosión X,
    afecta tanto a la tierra en las coordenas de la bomba, como a las tierras ubicadas en las esquinas cercanas a la bomba.
    En este caso se deben considerar varias posibilidades de cual coordenada se veria afectada por la explosión de la bomba,
    ya que existe la chance de que mas de alguna de las coordenadas supere los limites del tablero. Luego de explotar la coordenada
    donde su ubica la bomba, esta función consulta por la ubicacion de la fila y si esta se encuentra en los limites del tablero.
    En caso de que se encuentre en un limite, se consulta nuevamente por una situacion similar pero con la columna de la bomba.
    De esta manera, se puede deducir rapidamente si hay una posibilidad de que alguna de las esquinas que explote la bomba estaria
    fuera de los limites. De ser asi, la explosion dará la vuelta al tablero y afectará a otra celda dentro de los limites.
    TODOS LOS CASOS POSIBLES DE LIMITES FUERON CONSIDERADOS Y PROGRAMADOS PARA EVITAR PROBLEMAS DE SEGMENTATION FAULT.
*/
void ExplosionX(int fila, int columna){
    ((Bomba*)tablero[fila][columna])->tierra_debajo->vida = ((Bomba*)tablero[fila][columna])->tierra_debajo->vida - 1;
    if(((Bomba*)tablero[fila][columna])->tierra_debajo->vida <= 0){
        ((Bomba*)tablero[fila][columna])->tierra_debajo->vida = 0;
    }
    if((fila) == 0){
        if((columna) == 0){
            ((Tierra*)tablero[dimension-1][dimension-1])->vida = ((Tierra*)tablero[dimension-1][dimension-1])->vida - 1;
            if(((Tierra*)tablero[dimension-1][dimension-1])->vida <= 0){
                ((Tierra*)tablero[dimension-1][dimension-1])->vida = 0;
            }
            ((Tierra*)tablero[dimension-1][columna+1])->vida = ((Tierra*)tablero[dimension-1][columna+1])->vida - 1;
            if(((Tierra*)tablero[dimension-1][columna+1])->vida <= 0){
                ((Tierra*)tablero[dimension-1][columna+1])->vida = 0;
            }
            ((Tierra*)tablero[fila+1][dimension-1])->vida = ((Tierra*)tablero[fila+1][dimension-1])->vida - 1;
            if(((Tierra*)tablero[fila+1][dimension-1])->vida <= 0){
                ((Tierra*)tablero[fila+1][dimension-1])->vida = 0;
            }
            ((Tierra*)tablero[fila+1][columna+1])->vida = ((Tierra*)tablero[fila+1][columna+1])->vida - 1;
            if(((Tierra*)tablero[fila+1][columna+1])->vida <= 0){
                ((Tierra*)tablero[fila+1][columna+1])->vida = 0;
            }
        } else if((columna) == dimension-1){
            ((Tierra*)tablero[dimension-1][columna-1])->vida = ((Tierra*)tablero[dimension-1][columna-1])->vida - 1;
            if(((Tierra*)tablero[dimension-1][columna-1])->vida <= 0){
                ((Tierra*)tablero[dimension-1][columna-1])->vida = 0;
            }
            ((Tierra*)tablero[dimension-1][0])->vida = ((Tierra*)tablero[dimension-1][0])->vida - 1;
            if(((Tierra*)tablero[dimension-1][0])->vida <= 0){
                ((Tierra*)tablero[dimension-1][0])->vida = 0;
            }
            ((Tierra*)tablero[fila+1][columna-1])->vida = ((Tierra*)tablero[fila+1][columna-1])->vida - 1;
            if(((Tierra*)tablero[fila+1][columna-1])->vida <= 0){
                ((Tierra*)tablero[fila+1][columna-1])->vida = 0;
            }
            ((Tierra*)tablero[fila+1][0])->vida = ((Tierra*)tablero[fila+1][0])->vida - 1;
            if(((Tierra*)tablero[fila+1][0])->vida <= 0){
                ((Tierra*)tablero[fila+1][0])->vida = 0;
            }
        } else{
            ((Tierra*)tablero[dimension-1][columna-1])->vida = ((Tierra*)tablero[dimension-1][columna-1])->vida - 1;
            if(((Tierra*)tablero[dimension-1][columna-1])->vida <= 0){
                ((Tierra*)tablero[dimension-1][columna-1])->vida = 0;
            }
            ((Tierra*)tablero[dimension-1][columna+1])->vida = ((Tierra*)tablero[dimension-1][columna+1])->vida - 1;
            if(((Tierra*)tablero[dimension-1][columna+1])->vida <= 0){
                ((Tierra*)tablero[dimension-1][columna+1])->vida = 0;
            }
            ((Tierra*)tablero[fila+1][columna-1])->vida = ((Tierra*)tablero[fila+1][columna-1])->vida - 1;
            if(((Tierra*)tablero[fila+1][columna-1])->vida <= 0){
                ((Tierra*)tablero[fila+1][columna-1])->vida = 0;
            }
            ((Tierra*)tablero[fila+1][columna+1])->vida = ((Tierra*)tablero[fila+1][columna+1])->vida - 1;
            if(((Tierra*)tablero[fila+1][columna+1])->vida <= 0){
                ((Tierra*)tablero[fila+1][columna+1])->vida = 0;
            }
        }
    } else if((fila) == dimension-1){
        if((columna) == 0){
            ((Tierra*)tablero[fila-1][dimension-1])->vida = ((Tierra*)tablero[fila-1][dimension-1])->vida - 1;
            if(((Tierra*)tablero[fila-1][dimension-1])->vida <= 0){
                ((Tierra*)tablero[fila-1][dimension-1])->vida = 0;
            }
            ((Tierra*)tablero[fila-1][columna+1])->vida = ((Tierra*)tablero[fila-1][columna+1])->vida - 1;
            if(((Tierra*)tablero[fila-1][columna+1])->vida <= 0){
                ((Tierra*)tablero[fila-1][columna+1])->vida = 0;
            }
            ((Tierra*)tablero[dimension-1][dimension-1])->vida = ((Tierra*)tablero[dimension-1][dimension-1])->vida - 1;
            if(((Tierra*)tablero[dimension-1][dimension+1])->vida <= 0){
                ((Tierra*)tablero[dimension+1][dimension+1])->vida = 0;
            }
            ((Tierra*)tablero[dimension-1][columna+1])->vida = ((Tierra*)tablero[dimension-1][columna+1])->vida - 1;
            if(((Tierra*)tablero[dimension-1][columna+1])->vida <= 0){
                ((Tierra*)tablero[dimension-1][columna+1])->vida = 0;
            }
        } else if((columna) == dimension-1){
            ((Tierra*)tablero[fila-1][columna-1])->vida = ((Tierra*)tablero[fila-1][columna-1])->vida - 1;
            if(((Tierra*)tablero[fila-1][columna-1])->vida <= 0){
                ((Tierra*)tablero[fila-1][columna-1])->vida = 0;
            }
            ((Tierra*)tablero[fila-1][0])->vida = ((Tierra*)tablero[fila-1][0])->vida - 1;
            if(((Tierra*)tablero[fila-1][0])->vida <= 0){
                ((Tierra*)tablero[fila-1][0])->vida = 0;
            }
            ((Tierra*)tablero[0][columna-1])->vida = ((Tierra*)tablero[0][columna-1])->vida - 1;
            if(((Tierra*)tablero[0][columna-1])->vida <= 0){
                ((Tierra*)tablero[0][columna-1])->vida = 0;
            }
            ((Tierra*)tablero[0][0])->vida = ((Tierra*)tablero[0][0])->vida - 1;
            if(((Tierra*)tablero[0][0])->vida <= 0){
                ((Tierra*)tablero[0][0])->vida = 0;
            }
        } else{
            ((Tierra*)tablero[fila-1][columna-1])->vida = ((Tierra*)tablero[fila-1][columna-1])->vida - 1;
            if(((Tierra*)tablero[fila-1][columna-1])->vida <= 0){
                ((Tierra*)tablero[fila-1][columna-1])->vida = 0;
            }
            ((Tierra*)tablero[fila-1][columna+1])->vida = ((Tierra*)tablero[fila-1][columna+1])->vida - 1;
            if(((Tierra*)tablero[fila-1][columna+1])->vida <= 0){
                ((Tierra*)tablero[fila-1][columna+1])->vida = 0;
            }
            ((Tierra*)tablero[0][columna-1])->vida = ((Tierra*)tablero[0][columna-1])->vida - 1;
            if(((Tierra*)tablero[0][columna-1])->vida <= 0){
                ((Tierra*)tablero[0][columna-1])->vida = 0;
            }
            ((Tierra*)tablero[0][columna+1])->vida = ((Tierra*)tablero[0][columna+1])->vida - 1;
            if(((Tierra*)tablero[0][columna+1])->vida <= 0){
                ((Tierra*)tablero[0][columna+1])->vida = 0;
            }
        }        
    } else{
        if((columna) == 0){
            ((Tierra*)tablero[fila-1][dimension-1])->vida = ((Tierra*)tablero[fila-1][dimension-1])->vida - 1;
            if(((Tierra*)tablero[fila-1][dimension-1])->vida <= 0){
                ((Tierra*)tablero[fila-1][dimension-1])->vida = 0;
            }
            ((Tierra*)tablero[fila-1][columna+1])->vida = ((Tierra*)tablero[fila-1][columna+1])->vida - 1;
            if(((Tierra*)tablero[fila-1][columna+1])->vida <= 0){
                ((Tierra*)tablero[fila-1][columna+1])->vida = 0;
            }
            ((Tierra*)tablero[fila+1][dimension-1])->vida = ((Tierra*)tablero[fila+1][dimension-1])->vida - 1;
            if(((Tierra*)tablero[fila+1][dimension-1])->vida <= 0){
                ((Tierra*)tablero[fila+1][dimension-1])->vida = 0;
            }
            ((Tierra*)tablero[fila+1][columna+1])->vida = ((Tierra*)tablero[fila+1][columna+1])->vida - 1;
            if(((Tierra*)tablero[fila+1][columna+1])->vida <= 0){
                ((Tierra*)tablero[fila+1][columna+1])->vida = 0;
            }
        } else if((columna) == dimension-1){
            ((Tierra*)tablero[fila-1][columna-1])->vida = ((Tierra*)tablero[fila-1][columna-1])->vida - 1;
            if(((Tierra*)tablero[fila-1][columna-1])->vida <= 0){
                ((Tierra*)tablero[fila-1][columna-1])->vida = 0;
            }
            ((Tierra*)tablero[fila-1][0])->vida = ((Tierra*)tablero[fila-1][0])->vida - 1;
            if(((Tierra*)tablero[fila-1][0])->vida <= 0){
                ((Tierra*)tablero[fila-1][0])->vida = 0;
            }
            ((Tierra*)tablero[fila+1][columna-1])->vida = ((Tierra*)tablero[fila+1][columna-1])->vida - 1;
            if(((Tierra*)tablero[fila+1][columna-1])->vida <= 0){
                ((Tierra*)tablero[fila+1][columna-1])->vida = 0;
            }
            ((Tierra*)tablero[fila+1][0])->vida = ((Tierra*)tablero[fila+1][0])->vida - 1;
            if(((Tierra*)tablero[fila+1][0])->vida <= 0){
                ((Tierra*)tablero[fila+1][0])->vida = 0;
            }
        }else{
            ((Tierra*)tablero[fila-1][columna-1])->vida = ((Tierra*)tablero[fila-1][columna-1])->vida - 1;
            if(((Tierra*)tablero[fila-1][columna-1])->vida <= 0){
                ((Tierra*)tablero[fila-1][columna-1])->vida = 0;
            }
            ((Tierra*)tablero[fila-1][columna+1])->vida = ((Tierra*)tablero[fila-1][columna+1])->vida - 1;
            if(((Tierra*)tablero[fila-1][columna+1])->vida <= 0){
                ((Tierra*)tablero[fila-1][columna+1])->vida = 0;
            }
            ((Tierra*)tablero[fila+1][columna-1])->vida = ((Tierra*)tablero[fila+1][columna-1])->vida - 1;
            if(((Tierra*)tablero[fila+1][columna-1])->vida <= 0){
                ((Tierra*)tablero[fila+1][columna-1])->vida = 0;
            }
            ((Tierra*)tablero[fila+1][columna+1])->vida = ((Tierra*)tablero[fila+1][columna+1])->vida - 1;
            if(((Tierra*)tablero[fila+1][columna+1])->vida <= 0){
                ((Tierra*)tablero[fila+1][columna+1])->vida = 0;
            }
        }
    }
    return;
}
