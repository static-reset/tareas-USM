#ifndef TIERRA_H
#define TIERRA_H

typedef struct Tierra{
    int vida;
    int es_tesoro;

    /*
        Entero hay_bomba:
        Este entero solo será asignado el valor de 1 o 0.
        Si su valor es 1, indica con un "o" que tiene una bomba sobre su superficie al mostrar el tablero por consola.
        Si es 0, el tablero simplemente mostrará por consola la vida actual de la tierra.
    */
    int hay_bomba;
} Tierra;

#endif