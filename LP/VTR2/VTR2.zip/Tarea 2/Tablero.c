#include "Tierra.h"
#include "Tablero.h"
#include "Bomba.h"

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

void*** tablero;
int dimension;

/*
    Función IniciarTablero:
    Recibe un entero por parte del usuario, que presenta la dimensión deseada del tablero.
    Pide memoria para las filas y columnas del tablero, reserva la memoria de cada struct Tierra para cada celda y setea la seed del srand.
    Cada tierra recibe un valor de vida aleatorio entre 1 y 3, NO GENERA TESOROS y se designa como una Tierra sin bomba encima.
    Luego, el puntero de cada celda del tablero apuntará a la Tierra creada.
*/
void IniciarTablero(int n){
    dimension = n;
    tablero = calloc(dimension,sizeof(void**));
    if(tablero == NULL){
        printf("No se pudo crear el tablero.");
    }
    for (int i = 0; i < dimension; i++){
        tablero[i] = calloc(dimension,sizeof(void*));
    }
    /*
    Aquí se setea el seed de random, que servirá solamente para la partida del juego.
    */
    srand(time(0));
    for (int i = 0; i < dimension; i++){
        for (int j = 0; j < dimension; j++){
            Tierra* tierra_in = (Tierra*) malloc(sizeof(Tierra));
            tierra_in->vida = (rand() % 3) + 1;
            tierra_in->es_tesoro = 0;
            tierra_in->hay_bomba = 0;
            tablero[i][j] = tierra_in;
        }
    }
}

/*
    Funcion PasarTurno:
    Se recorre cada celda del tablero, revisando si existe alguna bomba con el indicador hay_bomba de cada Tierra.
    En el caso de que exista una, se llama a la función TryExplotar para reducir el contador
    de detonación de la bomba. En caso contrario, se consulta la siguiente celda.
*/
void PasarTurno(){
    for(int i = 0; i < dimension; i++){
        for (int j = 0; j < dimension; j++){
            if(((*(Tierra*)tablero[i][j]).hay_bomba == 0)){
              continue;
            }
            else if(((*(Bomba*)tablero[i][j]).tierra_debajo->hay_bomba) == 1){
                TryExplotar(i, j);
            }
        }
    }
    return;
}

/*
    Funcion ColocarBomba:
    Recibe una bomba, ya inicializada parcialmente por el usuario y las coordenadas pedidas por este para plantar la bomba.
    Se guarda en un puntero char la dirección de memoria de la Tierra presente en la celda que se obtiene con las coordenadas,
    seguido de apuntar con la variable tierra_debajo al struct. Luego, se redirige el puntero del tablero a la bomba, y se
    modifica el indicador de la Tierra para confirmar la existencia de una bomba sobre ella.
*/
void ColocarBomba(Bomba* b, int fila, int columna){
    char* dir_tierra = (char*) ((Tierra*) tablero[fila-1][columna-1]);
    b->tierra_debajo = (Tierra*) dir_tierra;
    tablero[fila-1][columna-1] = b;
    (*(Bomba*) tablero[fila-1][columna-1]).tierra_debajo->hay_bomba = 1;
    return;
}

/*
    Función MostrarTablero:
    Recorrre cada celda del tablero, mostrando por consola la vida de las Tierras presentes.
    También muestra las bombas en el turno seguido de ser plantadas, en este caso siempre
    van a ser las bombas de explosión X (ya que las de explosión punto se detonan instantaneamente).
    Se consulta el indicador hay_bomba para saber si se muestra la vida de una tierra o una bomba.
*/
void MostrarTablero(){
    for(int i = 0; i < dimension; i++){
        printf("\n\n");
        for(int j = 0; j < dimension; j++){
            if(((*(Tierra*)tablero[i][j]).hay_bomba == 0)){
                printf("| %d |", (*(Tierra*)tablero[i][j]).vida);
            } else if((*(Bomba*)tablero[i][j]).tierra_debajo->hay_bomba == 1){
                printf("| o |");
            }
            
        }
    }
    return;
}

/*
    Funcion MostrarBombas:
    Recorre cada celda del tablero en busca de las bombas que aun existan. Al encontrar una bomba
    muestra por consola los turnos restantes para explotar, sus coordenadas, el tipo de explosión que
    el usuario asignó y la vida restante de la tierra debajo. Se consulta al indicador hay_bomba para
    saber si existe una bomba, en caso contrario se continua con la siguiente iteración del ciclo.
*/
void MostrarBombas(){
    for (int i = 0; i < dimension; i++){
        for (int j= 0; j < dimension; j++){
            if(((*(Tierra*)tablero[i][j]).hay_bomba == 0)){
              continue;  
            }
            else if(((*(Bomba*)tablero[i][j]).tierra_debajo->hay_bomba) == 1){
                printf("\n\n-----------------\n\n");
                printf("Turnos para explotar: %d\n\n", (*(Bomba*)tablero[i][j]).contador_turnos);
                printf("Coordenadas: %d %d\n\n", i+1, j+1);
                if((*(Bomba*)tablero[i][j]).explotar == *ExplosionPunto){
                    printf("Forma explosion: ExplosionPunto\n\n");
                } else if((*(Bomba*)tablero[i][j]).explotar == *ExplosionX){
                    printf("Forma explosion: ExplosionX\n\n");
                }
                printf("Vida de Tierra Debajo: %d\n\n", (*(Bomba*)tablero[i][j]).tierra_debajo->vida);
                printf("-----------------\n\n");
            }
        }
    }
    return;
}


void VerTesoros(){
    // Su codigo
    return;
}

/*
    Funcion BorrarTablero:
    Usada para terminar el juego. Recorre cada celda del tablero, liberando la memoria de la Tierra
    y luego se quita la referencia de cada puntero de las celdas para evitar memory leaks y dangling.
    Al terminar de recorrer una fila, se libera su memoria y se quita la referencia su puntero
     y al recorrer todas las filas se libera la memoria original del tablero y se quita su referencia.
*/
void BorrarTablero(){
    for(int i = 0; i < dimension; i++){
        for(int j = 0; j < dimension; j++){
            free(tablero[i][j]);
            tablero[i][j] = NULL;
        }
        free(tablero[i]);
        tablero[i] = NULL;
    }
    free(tablero);
    tablero = NULL;
    return;
}