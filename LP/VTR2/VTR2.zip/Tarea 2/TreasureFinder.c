#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include "Tierra.h"
#include "Tablero.h"
#include "Bomba.h"

int main(int argc, char const *argv[])
{   
    /*
        Se crea un entero para el tamaño que el usuario pedirá para el juego.
    */
    int tamano;

    printf("¡Bienvenido a TreasureFinder!\n");
    printf("Indique el tamaño del tablero a jugar: \n");
    printf("1. 7x7  2. 10x10  3. 12x12\n");
    
    scanf("%d", &tamano);
    printf("Su input: %d\n", tamano);
    /*
        Se transforma el valor del tamaño dependiendo del input ingresado por el usuario.
        Se avisa en caso de que ingrese un valor no autorizado.
    */
    if (tamano == 1){
        tamano = 7;
    } else if (tamano == 2){
        tamano = 10;
    } else if (tamano == 3){
        tamano = 12;
    } else{
        printf("Input equivocado.\n");
        return 1;
    }

    IniciarTablero(tamano);
    printf("Empezando juego... ¡listo!\n");

    /*
        La variable booleana nos servirá para mantener el ciclo del juego hasta que
        el usuario desee eliminar el tablero.
    */
    bool juego = true;
    int turno = 1;
    while(juego != false){

        printf("\nTablero (Turno %d)\n", turno);
        MostrarTablero();
        printf("\n\n\nSeleccione una acción:\n\n");
        printf("1. Colocar Bomba  2. Mostrar Bombas  3. Mostrar Tesoros  4. Terminar Juego\n\n");
        int opcion;
        printf("Escoja una opción: ");
        scanf("%d", &opcion);
        
        /*
            Si el usuario quiere plantar una bomba: se reciben las coordenas deseadas por el usuario,
            junto con el tipo de explosión que quiere asignar a la bomba. En este condicional, se
            pide la memoria de la bomba y se asignan algunos de los atributos del struct Bomba.
            Luego se llama a la función ColocarBomba y continua con el siguiente turno con PasarTurno.
        */
        if(opcion == 1){
            printf("\nIndique coordenas de la bomba.\n\n");
            int fila, columna;
            printf("Fila: ");
            scanf("%d", &fila);
            printf("\nColumna: ");
            scanf("%d", &columna);
            int opc_bomb;
            printf("\nIndique forma en que explota la bomba:\n\n1. Punto  2. X\n\nSu input: ");
            scanf("%d", &opc_bomb);
            Bomba* new_bomb = (Bomba*) malloc(sizeof(Bomba));
            if(opc_bomb == 1){
                new_bomb->contador_turnos = 1;
                new_bomb->explotar = *ExplosionPunto;
            } else if(opc_bomb == 2){
                new_bomb->contador_turnos = 3;
                new_bomb->explotar = *ExplosionX;
            } else{
                printf("Input incorrecto.\n");
            }
            ColocarBomba(new_bomb, fila, columna);
            PasarTurno();
        }
        
        /*
            Si el usuario desea saber cuales bombas de tipo X quedan, se llama
            a la funcion MostrarBombas para recorrer el tablero y entregar
            la información detallada de cada bomba aun disponible.
        */
        else if(opcion == 2){
            MostrarBombas();
            continue;
        }
        /*else if(opcion == 3){
            VerTesoros();
        }*/
        
        /*
            Si el usuario desea terminar el juego se llama a la función BorrarTablero,
            la cual recorre cada celda para liberar la memoria disponible y quitar referencias.
            AVISO: en caso de existir bombas de tipo X está opción no será responsable de
            liberar su memoria, ya que está diseñada principalmente como una función para
            pruebas rapidas del programa. De todos modos la perdida de memoria es minima,
            ya que el numero de bombas aun activas no será más de 2 o 3.
        */
        else if(opcion == 4){
            BorrarTablero();
            printf("Se confirma el fin del juego.\n");
            juego = false;
        }
        turno++;
    }
    
    return 0;
}