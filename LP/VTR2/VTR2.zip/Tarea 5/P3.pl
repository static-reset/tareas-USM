%Hecho para declarar una combinación de la cerradura.
cerradura(1,4,5,1,0).

%Funcion verificar: recibe 5 parametros que sirven como un intento de descifrar la cerradura y retorna el resultado.
%Se crean funciones auxiliares A que recuerdan los valores originales de la cerradura-
%Se llama a la función 'acierto' para verificar que las funciones sean iguales:
%si son iguales, entonces la variable de calculo R suma 1, en caso contrario no suma.
%Al terminar de verificar, se chequea la suma de todas las variables R:
%si es igual a 5, entonces la contraseña fue descubierta, en caso contrario se retorna el numero de aciertos obtenidos.
verificar(X1,X2,X3,X4,X5,Aciertos):-
    cerradura(A1,A2,A3,A4,A5),
    acierto(X1,A1,R1),
    acierto(X2,A2,R2),
    acierto(X3,A3,R3),
    acierto(X4,A4,R4),
    acierto(X5,A5,R5),
    Total_aciertos is R1 + R2 + R3 + R4 + R5,
    Total_aciertos < 5,
    Aciertos is Total_aciertos.

verificar(X1,X2,X3,X4,X5,"Contraseña descubierta"):-
    cerradura(A1,A2,A3,A4,A5),
    acierto(X1,A1,R1),
    acierto(X2,A2,R2),
    acierto(X3,A3,R3),
    acierto(X4,A4,R4),
    acierto(X5,A5,R5),
    Total_aciertos is R1 + R2 + R3 + R4 + R5,
    Total_aciertos = 5.

%Funcion auxiliar 'acierto': comprueba si los dos primeros parametros son iguales.
%Si se cumple, el entrega un 1 (true), caso contrario (y no importan los valores) entrega un 0 (false)
acierto(A, A, 1) :- !.
acierto(_, _, 0).