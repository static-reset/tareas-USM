%Hechos para armar el grafo y las direcciones de los nodos del dibujo.
sigue(p1, p2).
sigue(p2, p3).
sigue(p3, p4).
sigue(p4, p5).
sigue(p5, p6).
sigue(p6, p7).
sigue(p7, p8).
sigue(p8, p1).
sigue(p1, p9).
sigue(p9, p10).
sigue(p10, p11).
sigue(p11, p12).
sigue(p12, p13).
sigue(p13, p14).
sigue(p1, p15).
sigue(p15, p16).
sigue(p16, p20).
sigue(p20, p21).
sigue(p21, p22).
sigue(p7, p17).
sigue(p17, p18).
sigue(p18, p19).

%Funcion auxiliar 'anteriores': esta funcion recibe el nodo de interes y una lista
%(generalmente vacia), sirve para hacer un paso facil a 'seguidores'.
anteriores(Nodo, Anteriores):-
    seguidores(Nodo, [], Anteriores).

%Funcion auxiliar 'seguidores': recibe el nodo de interes, una lista de nodos ya visitados
%y una tercera lista que guarda el nodo actual en la cabeza. Se revisa si el nodo actual
%ya fue visitado: si es así entonces se devuelve una lista vacía. En caso contrario,
%se consigue el nodo que sigue a nuestro nodo actual y se llama recursivamente a esta
%función, agregando el nodo actual a la lista de visitados.
seguidores(Nodo, Visitados, [Nodo | Anteriores]):-
    \+ member(Nodo, Visitados),
    sigue(NodoX, Nodo),
    seguidores(NodoX, [Nodo | Visitados], Anteriores),
    !.
seguidores(_, _, []).

%Función principal: recibe el nodo de interés e indica si es de la cadena principal o no.
%Esto se deduce por el largo de nodos anteriores al nodo de interés: si el largo es
%menor o igual a 7, eso quiere decir que si o si el nodo es uno de los 8 presentes en la rama principal.
%En caso de que su largo sea mayor o igual a 8, esto dice que es un nodo fuera de la rama principal,
%ya que al ver un nodo de la rama principal sus anteriores no van a ser mas de 7 (ya que son 8 nodos en la rama principal).
principal(Nodo, "No es de la rama principal"):-
    anteriores(Nodo, Seguidores),
    delete(Seguidores, Nodo, Seguidores1),
	length(Seguidores1, Largo),
    Largo >= 8,
    print(Seguidores1).

principal(Nodo, "Es de la rama principal"):-
    anteriores(Nodo, Seguidores),
    delete(Seguidores, Nodo, Seguidores1),
    length(Seguidores1, Largo),
    Largo =< 7,
    print(Seguidores1).