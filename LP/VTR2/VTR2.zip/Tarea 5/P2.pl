%Hecho para declarar una combinación de la cerradura.
cerradura(1,4,5,1,0).

%Funcion verificar: recibe 5 numeros que sirven para descifrar la cerradura.
%Para esto se obtiene la diferencia entre los numeros que se reciben junto con
%los numeros de la cerradura (X1-A1). Luego se obtiene un promedio entre los
%resultados de todas las consultas. Dependiendo del resultado se determina
%si el intento está cerca, lejos o ha acertado la combinación de la cerradura.

%Se utilizan variables A para obtener los valores originales de la cerradura y
%evitar una nueva declaración del hecho. Luego, usando la declaración "_ is _", podemos
%asignar a otras variables auxiliares el resultado de la diferencia entre el
%intento del usuario y el valor original. Se usa "abs" para evitar resultados negativos.
%Finalmente, se asigna a la variable R el resultado del promedio de diferencias
%usando nuevamente la declaración "_ is _".

%Caso "lejos": cuando el promedio de las diferencias es mayor o igual a 1.
verificar(X1,X2,X3,X4,X5,"Lejos"):-
    cerradura(A1,A2,A3,A4,A5),
    Calc1 = abs(X1-A1),
    Calc2 = abs(X2-A2),
    Calc3 = abs(X3-A3),
    Calc4 = abs(X4-A4),
    Calc5 = abs(X5-A5),
    R is (Calc1 + Calc2 + Calc3 + Calc4 + Calc5)/5,
    R >= 1.

%Caso "cerca": cuando el promedio de las diferencias está entre 0 y 1.
verificar(X1,X2,X3,X4,X5,"Cerca"):-
    cerradura(A1,A2,A3,A4,A5),
    Calc1 = abs(X1-A1),
    Calc2 = abs(X2-A2),
    Calc3 = abs(X3-A3),
    Calc4 = abs(X4-A4),
    Calc5 = abs(X5-A5),
    R is (Calc1 + Calc2 + Calc3 + Calc4 + Calc5)/5,
    R > 0, R < 1.

%Caso "descubierto": cuando el promedio de las diferencias es igual a 0.
verificar(X1,X2,X3,X4,X5,"Contraseña descubierta"):-
    cerradura(A1,A2,A3,A4,A5),
    Calc1 = abs(X1-A1),
    Calc2 = abs(X2-A2),
    Calc3 = abs(X3-A3),
    Calc4 = abs(X4-A4),
    Calc5 = abs(X5-A5),
    R is (Calc1 + Calc2 + Calc3 + Calc4 + Calc5)/5,
    R = 0.