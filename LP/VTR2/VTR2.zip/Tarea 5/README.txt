Nombre: Cristobal Andrés Pino Poblete
Rol: 202104597-k

Instrucciones: extraer los archivos en una carpeta. Utilizar el sitio web SWISH Prolog para poder probar los programas y sus consultas. Copiar el codigo de cada archivo y pegarlo en el sitio. Luego en la casilla inferior de la derecha se escriben las consultas que se quieran hacer para probar el programa. Todos los casos de prueba del PDF fueron ejecutados con éxito, además de otros más para verificar la versatilidad del programa.