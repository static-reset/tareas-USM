%Hechos para descifrar una pareja de bits y asignar una letra.
cifrado([0,0],a).
cifrado([0,1],g).
cifrado([1,0],c).
cifrado([1,1],t).

%Función descifrar: si recibe una lista vacía, retorna una lista vacía.
%Al recibir una lista de bits parejos, separa la lista en la cabeza (par de bits)
%y en el resto del mensaje y  luego consulta con el hecho 'cifrado' para ver cual
%letra se les debe asignar. Lo que entregue 'cifrado' se asigna a la cabeza de R,
% y luego se llama recursivamente a 'descifrar' para continuar con el resto del mensaje.
descifrar([],[]).
descifrar([Codigo1,Codigo2|CodigoResto],[Resp1|RespResto]):-
    cifrado([Codigo1,Codigo2],Resp1),
    descifrar(CodigoResto,RespResto). 